#include "stdafx.h"
#include "Nemo.h"
#include "stdafx.h"
#include "Nemo.h"
#include "Game.h"
#include "GameState.h"
#include "MissileBullet.h"


Nemo::Nemo()
{
	SetID(PLAYER);
	SetLife(800);
	SetMaxLife(800);
	SetEnergy(500);
	SetMaxEnergy(500);

	SetShip("Nemo");
}


Nemo::~Nemo()
{
}


Nemo::Nemo(int _x, int _y, const char * const _picture, System::ConsoleColor _fg, System::ConsoleColor _bg,
	int _score, int _diff, const char * const _name) : Player(_x, _y, _picture, _fg, _bg, _score, _diff, _name)
{
	SetY(_y);
	SetX(_x);
	SetPicture(_picture);
	SetLife(400);
	SetMaxLife(400);
	SetFG(_fg);
	SetBG(_bg);
	SetEnergy(300);
	SetMaxEnergy(300);
	SetID(PLAYER);
	SetShip("Nemo");
}




bool Nemo::Input()
{
	vector<BaseObject*>& tempObjects = GameState::GetObjects();


	bool collided = false;

	if (GetAsyncKeyState(VK_ESCAPE))
	{
		Game::ChangeState(MENU_STATE);
		//return false;
	}

	//Let's do movement here.... shortly.
	int dx, dy;
	dx = dy = 0;

	if (GetAsyncKeyState('W') || GetAsyncKeyState(VK_UP)) dy = -1;
	if (GetAsyncKeyState('S') || GetAsyncKeyState(VK_DOWN)) dy = 1;
	if (GetAsyncKeyState('A') || GetAsyncKeyState(VK_LEFT)) dx = -1;
	if (GetAsyncKeyState('D') || GetAsyncKeyState(VK_RIGHT)) dx = 1;
	if (GetAsyncKeyState('T'))
	{
		SetX(GetX() + rand() % 11 - 5);
		SetY(GetX() + rand() % 11 - 5);
	}


	//Am I moving?
	if (dx || dy)
	{
		int newX = GetX() + dx;
		int newY = GetY() + dy;

		//Check to make sure my potential position is safe to move to
		if (newX + GetWidth() <= System::Console::WindowWidth() &&
			newX >= 0
			&&
			newY + GetHeight() <= System::Console::WindowHeight() - 2 &&
			newY >= 1)
		{
			decltype(tempObjects.size()) i = 1;
			for (; i < tempObjects.size(); ++i)
			{
				//TONS of temp variables!  Yeah!
				int myLeft = newX;
				int myRight = newX + GetWidth();
				int theirLeft = tempObjects[i]->GetX();
				int theirRight = tempObjects[i]->GetX() + tempObjects[i]->GetWidth();
				int myTop = newY;
				int myBottom = newY + GetHeight();
				int theirTop = tempObjects[i]->GetY();
				int theirBottom = theirTop + tempObjects[i]->GetHeight();

				if (myRight <= theirLeft ||
					myLeft >= theirRight ||
					myTop >= theirBottom ||
					myBottom <= theirTop ||
					tempObjects[i]->GetID() == PLAYER_MISSILE)
				{
					collided = false;
				}
				else
				{
					collided = true;
					break;
				}
			}// for loop

			if (!collided)
			{
				SetX(newX);
				SetY(newY);
			}
		}
	}

	//Fire
	if (GetAsyncKeyState(VK_NUMPAD8) || GetAsyncKeyState(VK_SPACE) && (GetEnergy() >= 10))
	{
		MissileBullet* m = new MissileBullet(); // dynamic_cast<Missile*>(tempObjects[3]);

		m->SetAlive(true);
		m->SetX(GetX() + (GetWidth() >> 1));
		m->SetY(GetY() + GetHeight() - 1);
		m->SetXYVel(0, -1);
		m->SetID(PLAYER_MISSILE);
		SetEnergy(GetEnergy() - 10);
		// this is npw a reference 
		tempObjects.push_back(m);
	}

	if (GetAsyncKeyState(VK_NUMPAD4))
	{
		MissileBullet* m = new MissileBullet();

		m->SetAlive(true);
		m->SetX(GetX() - 1);
		m->SetY(GetY());
		m->SetXYVel(-1, 0);

		tempObjects.push_back(m);
	}

	if (GetAsyncKeyState(VK_NUMPAD5))
	{
		MissileBullet* m = new MissileBullet();
		MissileBullet* m1 = new MissileBullet();
		MissileBullet* m2 = new MissileBullet();
		MissileBullet* m3 = new MissileBullet();
		MissileBullet* m4 = new MissileBullet();
		MissileBullet* m5 = new MissileBullet();
		MissileBullet* m6 = new MissileBullet();
		MissileBullet* m7 = new MissileBullet();

		//Straight up
		m->SetAlive(true);
		m->SetX(GetX() - 1);
		m->SetY(GetY());
		m->SetXYVel(-1, 0);

		//Up left
		m1->SetAlive(true);
		m1->SetX(GetX() - 1);
		m1->SetY(GetY());
		m1->SetXYVel(-1, -1);

		//Left
		m2->SetAlive(true);
		m2->SetX(GetX() - 1);
		m2->SetY(GetY());
		m2->SetXYVel(-1, 0);

		//Down left
		m3->SetAlive(true);
		m3->SetX(GetX() - 1);
		m3->SetY(GetY());
		m3->SetXYVel(-1, 1);

		//Down
		m4->SetAlive(true);
		m4->SetX(GetX() - 1);
		m4->SetY(GetY());
		m4->SetXYVel(0, 1);

		//Down right
		m5->SetAlive(true);
		m5->SetX(GetX() - 1);
		m5->SetY(GetY());
		m5->SetXYVel(1, 1);

		//Right
		m6->SetAlive(true);
		m6->SetX(GetX() - 1);
		m6->SetY(GetY());
		m6->SetXYVel(1, 0);

		//Up right
		m7->SetAlive(true);
		m7->SetX(GetX() - 1);
		m7->SetY(GetY());
		m7->SetXYVel(1, -1);

		tempObjects.push_back(m);
		tempObjects.push_back(m1);
		tempObjects.push_back(m2);
		tempObjects.push_back(m3);
		tempObjects.push_back(m4);
		tempObjects.push_back(m5);
		tempObjects.push_back(m6);
		tempObjects.push_back(m7);
	}

	if (GetAsyncKeyState(VK_NUMPAD9))
	{
		MissileBullet* m = new MissileBullet();

		m->SetAlive(true);
		m->SetX(GetX() + (GetWidth() >> 1));
		m->SetY(GetY() - 1);
		m->SetXYVel(1, -1);

		tempObjects.push_back(m);
	}

	if (GetAsyncKeyState(VK_NUMPAD7))
	{
		MissileBullet* m = new MissileBullet();

		m->SetAlive(true);
		m->SetX(GetX() + (GetWidth() >> 1));
		m->SetY(GetY() - 1);
		m->SetXYVel(-1, -1);

		tempObjects.push_back(m);
	}

	if (GetAsyncKeyState(VK_NUMPAD2))
	{
		MissileBullet* m = new MissileBullet();

		m->SetAlive(true);
		m->SetX(GetX() + (GetWidth() >> 1));
		m->SetY(GetY() - 1);
		m->SetXYVel(0, 1);

		tempObjects.push_back(m);
	}

	return true;
}

void Nemo::Update(int _frame)
{
	
	frame = _frame;
	SetDiff(GetLifeTime());

	if (GetEnergy() < 300)
	{
		SetEnergy(GetEnergy() + 5);
	}

	if (GameState::GetSheats() & POINTS_FLAG)
	{
		SetScore(GetScore() + 100);
	}
}

void Nemo::Render() const
{
	//Display my HUD
	//System::Console::SetCursorPosition(1, 0);
	//cout << "Name: " << this->GetName();
	//System::Console::SetCursorPosition((System::Console::WindowWidth() >> 1) - 10, 0);
	//cout << "Score: " << this->GetScore();
	//System::Console::SetCursorPosition(System::Console::WindowWidth() - 23, 0);
	//cout << "Life: " << this->GetLife();
	//System::Console::SetCursorPosition(System::Console::WindowWidth() - 7, 0);
	//cout << "Diff: " << this->GetDiff();

	//Use this to do a simple render, which base object already handles)
	Player::Render();
}