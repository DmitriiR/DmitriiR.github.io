#include "stdafx.h"
#include "BaseObject.h"
#include "GameState.h"


BaseObject::BaseObject()
{
	//picture = NULL;
}

BaseObject::~BaseObject()
{
	//delete[] picture;
}



BaseObject::BaseObject(int _x, int _y,char const * const _picture, System::ConsoleColor _fg, System::ConsoleColor _bg)
{
	//picture = NULL;

	SetX(_x);
	SetY(_y);
	SetPicture(_picture);
	CalcWH();
	SetFG(_fg);
	SetBG(_bg);

	//" / \\\n |^| \n<[|]>"
	//"  | |   \n / ^ \\ \n<[|_|]>"
	//" / \\\n<[^]>"
	
	int picY = 0;
	int picX = 0;
	Cell<> * tempCell = new Cell<>;

	for (int i = 0; i < (int)strlen(_picture); i++)
	{
		
		switch (_picture[i])
		{
		case '\n':
			picY++;
			picX = 0;
			break;
		case ' ':
			picX++;
			

			break;
		default:

			tempCell->SetSym(_picture[i]);
			tempCell->oX = picX;
			tempCell->oY = picY;

			tempCell->SetBG(_bg);
			tempCell->SetFG(_fg);
			arr.push_back(*tempCell);
			picX++;
			tempCell->Show(10,10);
			break;
		}
		
		//if (_picture[i] == '\n' )
		//{
		//	picY++;
		//	picX = 0;
		//	//i++;
		//} else
		//
		//if (_picture[i] != ' ')
		//{

		//	tempCell->SetSym(_picture[i]);
		//	tempCell->oX = picX;
		//	tempCell->oY = picY;

		//	tempCell->SetBG(_bg);
		//	tempCell->SetFG(_fg);
		//	arr.push_back(*tempCell);
		//} else	if (_picture[i] == ' ')
		//{
		////	tempCell->oX = picX;
		////	tempCell->oY = picY;
		//	picX++;
		////	continue;
		//}
		////picX++;
		//
		
	//	tempCell->Show(10,10);
	}
	//arr[i].Show(20,10);

	//cout << "\n\n\n";
	//system("pause");


	
}

// overloaded for the bullet
BaseObject::BaseObject(int _x, int _y, char _picture, System::ConsoleColor _fg, System::ConsoleColor _bg)
{
	//picture = NULL;

	SetX(_x);
	SetY(_y);
	//SetPicture(_picture);
	CalcWH();
	SetFG(_fg);
	SetBG(_bg);

	//" / \\\n |^| \n<[|]>"
	//"  | |   \n / ^ \\ \n<[|_|]>"
	//" / \\\n<[^]>"

	int picY = 0;
	int picX = 0;
	Cell<> * tempCell = new Cell<>;

	for (int i = 0; i < 1; i++)
	{
		if (_picture == '\n')
		{
			picY++;
			picX = 0;
			i++;
		}
		if (_picture != ' ')
		{

			tempCell->SetSym(_picture);
			tempCell->oX = picX;
			tempCell->oY = picY;

			tempCell->SetBG(_bg);
			tempCell->SetFG(_fg);
		}
		else if (_picture == ' ')
		{
			picX++;
			continue;
		}
		picX++;

		arr.push_back(*tempCell);
		//	tempCell->Show(10,10);
	}
	//arr[i].Show(20,10);

	//cout << "\n\n\n";
	//system("pause");



}


BaseObject::BaseObject(BaseObject const& _obj)
{
	//picture = NULL;
	

	SetX(_obj.x);
	SetY(_obj.y);
	SetPicture(_obj.picture.c_str());
	CalcWH();
	SetFG(_obj.fg);
	SetBG(_obj.bg);
}

BaseObject& BaseObject::operator=(BaseObject const& _obj)
{

	if (this != &_obj)
	{
		SetX(_obj.x);
		SetY(_obj.y);
		SetPicture(_obj.picture.c_str());
		SetWidth(_obj.width);
		SetHeight(_obj.height);
		SetFG(_obj.fg);
		SetBG(_obj.bg);
	}

	return *this;
}

bool BaseObject::Input()
{
	return true;
}

void BaseObject::Update(int _frame)
{

}

void BaseObject::Render() const
{
	System::Console::SetCursorPosition(x, y);
	System::Console::ForegroundColor(fg);
	System::Console::BackgroundColor(bg);

	if (GameState::GetSheats() & ENEMY_MOVE)
	{
		System::Console::SetCursorPosition(0,36);
		cout << "Enemies Frozen";
	}

	if (GameState::GetSheats() & POINTS_FLAG)
	{
		System::Console::SetCursorPosition(0, 37);
		cout << "Racking Up Points";
	}

	if (GameState::GetSheats() & ENEMY_SHOOT)
	{
		System::Console::SetCursorPosition(0, 35);
		cout << "Enemies Powerless";
	}
	

	for (int i = 0; i < (int)arr.size(); i++)
	{
		arr[i].Show(x,y);
	}

	//int yCount = 0;

	//decltype(strlen(picture.c_str())) i = 0;
	//for (; i < picture.length(); ++i)
	//{
	//	if (picture[i] == '\n')
	//	{
	//		System::Console::SetCursorPosition(x, y + ++yCount);
	//	}
	//	else
	//	{
	//		cout << picture[i];
	//	}
	//}
	
	System::Console::ResetColor();
}

void BaseObject::CalcWH()
{

	
	
	
	height = 1;
	width = 1;

	unsigned int i = 0;
	for (; i < strlen(picture.c_str()); ++i)
	{
		if (picture[i] == '\n')
		{
			++height;
			width = 0;
		}
		else
			++width;

	}
}