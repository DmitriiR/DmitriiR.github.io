#include "stdafx.h"
#include "MissileBomb.h"
#include "GameState.h"
#include "Player.h"
#include "Enemy.h"

#define EXPLOSIONSPEED 10

MissileBomb::MissileBomb()
{
	velVec.resize(2);
	char buff[2];
	sprintf(buff, "%c", (char)179);
	SetPicture(buff); // destination, format string - %c character designation %i integer %s string, rest of the parameters can be listed  
	CalcWH();
	SetFG(System::ConsoleColor::Cyan);
	SetBG(System::ConsoleColor::Black);
	SetX(-1);
	SetY(-1);

	SetAlive(false);

	//SetID(MISSILE);
}


MissileBomb::~MissileBomb()
{
}

bool MissileBomb::Input()
{
	return true;
}

void MissileBomb::Update(int _frame)
{
	if (GetAlive())
	{
		bool colliding = false;
		//Check collisions
		vector<BaseObject*> tempObjects = GameState::GetObjects();

		decltype(tempObjects.size()) i = 0;
		for (; i < tempObjects.size(); ++i)
		{


			if (tempObjects[i]->GetID() == ENEMY)
			{
				//Checking current XPos instead of updated XPos
				BaseObject* target = tempObjects[i];
				if (GetX() + GetWidth() <= target->GetX() ||
					GetX() > target->GetX() + target->GetWidth() ||
					GetY() > target->GetY() + target->GetHeight() ||
					GetY() + GetHeight() < target->GetY())
				{
					colliding = false;
					continue;
				}
				else
				{
					if (GetID() != ENEMY_MISSILE)
					{
						System::Console::SetCursorPosition(GetX(), GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "*";
						System::Console::SetCursorPosition(GetX() - 1, GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "{ }";
						System::Console::SetCursorPosition(GetX() - 2, GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "(   )";

						target->SetLife(target->GetLife() - GetDamage());

						colliding = false;
						SetAlive(false);
						Player* p = dynamic_cast<Player*>(tempObjects[0]);
						p->SetScore(p->GetScore() + 1);
					}
					break;
				}
			}


			if (tempObjects[i]->GetID() == PLAYER)
			{
				//Checking current XPos instead of updated XPos
				BaseObject* target = tempObjects[i];
				if (GetX() + GetWidth() < target->GetX() ||
					GetX() > target->GetX() + target->GetWidth() ||
					GetY() > target->GetY() + target->GetHeight() ||
					GetY() + GetHeight() < target->GetY())

				{

					colliding = false;

					continue;
				}
				else
				{

					if (GetID() != PLAYER_MISSILE)
					{

						System::Console::SetCursorPosition(GetX(), GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "*";
						System::Console::SetCursorPosition(GetX() - 1, GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "{ }";
						System::Console::SetCursorPosition(GetX() - 2, GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "(   )";


						target->SetLife(target->GetLife() - GetDamage());
						colliding = false;
						SetAlive(false);

					}
					//Player* p = dynamic_cast<Player*>(tempObjects[0]);
					//p->SetScore(p->GetScore() + 1);

					break;
				}

			}

		}


		int newX = GetX() + velX;
		int newY = GetY() + velY;
		if (newX + GetWidth() <= System::Console::WindowWidth() &&
			newX >= 0
			&&
			newY + GetHeight() <= System::Console::WindowHeight() &&
			newY >= 1)
		{
			colliding = false;
		}
		else
		{
			colliding = true;
			SetAlive(false);
		}

		if (!colliding)
		{
			SetX(newX);
			SetY(newY);
		}

	}
}

void MissileBomb::Render() const
{
	if (GetAlive())
		BaseObject::Render();

}

void MissileBomb::Explosion()
{
}