#pragma once
#include "BaseObject.h"

class BaseObject;


class Level : public BaseObject
{
	int m_health;

	
	//static BaseObject** walls;

public:
	Level();
	
	
	
	~Level();
	void Load();
	void SetHealth(int _health);
	int GetHealth();



};

