#pragma once
#include "Player.h"


//     | | 
//    / ^ \ 
//  <[| _ |]>

class Falcon : public Player
{
	int m_damage;
	int m_shield;
	int m_speed;


public:
	Falcon();
	~Falcon();

	Falcon(int _x, int _y, const char * const _picture, System::ConsoleColor _fg, System::ConsoleColor _bg,
		int _score, int _diff, const char * const _name);

	// function calls
	bool Input();
	void Update(int _frame);
	void Render() const;

};

