#pragma once
#include "BaseObject.h"
#include "Player.h"

class Enemy : public BaseObject
{
private:
	//int moveDirX = 1;
	//int moveDirY = 1;
	
	int moveDirX = 1 - (rand() % 2 * 2);
	
	int moveDirY = 1 - (rand() % 2 * 2);


	// additional fields to come 
//	int m_hp = 100; 

public:
	Enemy();
		~Enemy();

	Enemy(int _x, int _y, const char * const _picture, System::ConsoleColor _fg, System::ConsoleColor _bg);
	
	bool Input();
	void Update(int _frame);
	void Render() const;

	void ReverseDirection() { moveDirY = !moveDirY; };
	// accessors 

//	int GetHealth() { return m_hp; }

	// mutators 

//	void SetHealth(int _health) { m_hp = _health; }

};

