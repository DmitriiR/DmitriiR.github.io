#pragma once
class BaseState
{
public:
	BaseState();
virtual ~BaseState();

//Function that handles all potential user input
virtual bool Input() = 0;
//Updates based off input or some sort of frame count
virtual void Update(int _frame) = 0;
//Simply displays the object
virtual void Render() const = 0;

virtual void Enter() = 0;
virtual void Exit() = 0;

};

