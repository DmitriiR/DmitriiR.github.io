#pragma once
#include "Cell.h"
#include "time.h"
class BaseObject;
class BaseState;


enum StateNum { MENU_STATE = 0, GAME_STATE };
static int frame = 0;

class Game
{
private:
	//BaseObject* objects;
	//BaseObject* ships;


	static BaseState* currentState;
	static BaseState* states[2];
	Cell<>* cells;
	
	time_t timer;
	
	

	bool play = true;

public:
	Game();
	~Game();
	
	//static bool m_sound;
	// primary function
	void Play();

	// this allows for objects to cross check for collisions
	//static BaseObject** GetObjects() { return objects; }


	void Input();
	void Update(int _frame);
	void Render() const;

	// my menu functions

	void PlayerSelection();
	void LoadLevel();
	void ShowStars();

	

	static void ChangeState(StateNum _num);
	
};

