#pragma once
#include "BaseObject.h"

struct PlayerInfo
{
	char name[32];
	char ship[10];
	int score, diff;

	friend ostream& operator<<(ostream& _os, PlayerInfo& _info);
};

class Player : public BaseObject
{
private:
	
	string name;
	//char *name;
	string ship;
	int m_energy;
	int m_maxEnergy;
	
	int score, diff;


public:
	
	Player();
	~Player();
	
	Player(int _x, int _y, const char * const _picture, System::ConsoleColor _fg, System::ConsoleColor _bg,
		int _score, int _diff, const char * const _name);

	int GetScore() const { return score; }
	int GetDiff() const { return diff; }
	int GetEnergy() const { return m_energy; }
	int GetMaxEnergy() const { return m_maxEnergy; }


	const char * const GetName() const { return name.c_str();}
	const char * const GetShip() const { return ship.c_str();}

	//Mutators
	void SetScore(int _score) { score = _score; if (score < 0) score = 0; }
	void SetDiff(int _diff) { diff = _diff; }
	void SetName(const char * const _name) { name = _name; }
	void SetShip(const char * const _ship) { ship = _ship; }
	void SetEnergy(int _energy) { m_energy = _energy; 
	if (m_energy < 0) m_energy = 0;}
	void SetMaxEnergy(int _maxEnergy) {	m_maxEnergy = _maxEnergy;}

	//My base overloads
	virtual bool Input();
	virtual void Update(int _frame);
	virtual void Render() const;

};

