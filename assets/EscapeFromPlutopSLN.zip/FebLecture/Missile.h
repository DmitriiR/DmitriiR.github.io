#pragma once
#include "BaseObject.h"

#define velX velVec[0]
#define velY velVec[1]

class Missile : public BaseObject
{
private:
	vector<int> velVec;
	int m_damage = 20;

public:
	Missile();
	~Missile();

	//Accessors
	int GetXVel() const { return velX; }//velVec[0];}
	int GetYVel() const { return velY; }
	void GetVel(int& _x, int& _y) const { _x = velX; _y = velY; }
	int GetDamage()  const { return m_damage; }

	//Mutators
	void SetXVel(int _x) { velX = _x; }
	void SetYVel(int _y) { velY = _y; }
	void SetXYVel(int _x, int _y) { velX = _x; velY = _y; }
	void SetDamage(int _damage) { m_damage = _damage; }

	bool Input();
	void Update(int _frame);
	void Render() const;


	void Explosion();
};

