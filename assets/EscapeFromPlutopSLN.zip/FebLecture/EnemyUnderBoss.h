#pragma once
#include "BaseObject.h"
#include "Player.h"

class EnemyUnderBoss :	public BaseObject
{
private:
	int moveDirX = 1 - (rand() % 2 * 2);

	int moveDirY = 1 - (rand() % 2 * 2);

public:
	EnemyUnderBoss();
~EnemyUnderBoss();

EnemyUnderBoss(int _x, int _y, const char * const _picture, System::ConsoleColor _fg, System::ConsoleColor _bg);

bool Input();
void Update(int _frame);
void Render() const;

};



