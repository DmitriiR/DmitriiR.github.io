#pragma once
//#include "BaseObject.h"
#include "stdafx.h"

template<class Offset = int, class Symbol = char>
struct Cell 
{
	
	Offset oX, oY;
	System::ConsoleColor fg, bg;
	Symbol sym;

public:
	Cell();
	~Cell();
	
	Cell(int _x, int _y, System::ConsoleColor _fg, System::ConsoleColor _bg, char _sym);

	//Accessors 
	int GetX() const { return oX; }
	int GetY() const { return oY; }
	char const GetSym() const {	return sym; }
	System::ConsoleColor GetFG() const { return fg; }
	System::ConsoleColor GetBG() const { return bg; }

	//Mutators
	//void SetX(int _oX) { oX = _oX; }
	//void SetX(int _oY) { oY = _oY; }
	void SetSym(char _sym) { sym = _sym; }
	void SetFG(System::ConsoleColor _fg) { fg = _fg; }
	void SetBG(System::ConsoleColor _bg) { bg = _bg; }
	
	bool Show(int _left, int _top) const;
	//const Offset & operator[](int _index);
	
	Offset& operator[](int _index);
	const Offset& operator[](int _index) const;
	
};

template<class Offset, class Symbol>
inline Cell<Offset, Symbol>::Cell()
{
}

template<class Offset, class Symbol>
inline Cell<Offset, Symbol>::~Cell()
{
}

template<typename Offset, class Symbol>
Cell<Offset, Symbol>::Cell(int _x, int _y, System::ConsoleColor _fg, System::ConsoleColor _bg, char _sym)
{
	oX = _x;
	oX = _y;
	fg = _fg;
	bg = _bg;
	sym = _sym;
}


template<typename Offset,class Symbol>
bool Cell<Offset, Symbol>::Show(int _left, int _top) const
{
	
	System::Console::ForegroundColor(GetFG());
	System::Console::BackgroundColor(GetBG());
	
	

	//System::Console::BackgroundColor(GetBG());
		if (!(_left < 0 || _left > System::Console::WindowWidth() || _top < 0 || _top > System::Console::WindowHeight() - 2))
		{
			System::Console::SetCursorPosition(_left + oX,_top + oY);
			cout << GetSym();
			return true;
		}
		else return false;
}

template<class Offset, class Symbol>
inline Offset & Cell<Offset, Symbol>::operator[](int _index)
{
	if (index == 0)
	{
		return oX;
	}
	else if (index == 1)
	{
		return oY;
	}
}

template<class Offset, class Symbol>
inline const Offset & Cell<Offset, Symbol>::operator[](int _index) const
{
	if (index == 0)
	{
		return oX;
	}
	else if (index == 1)
	{
		return oY;
	}
}


