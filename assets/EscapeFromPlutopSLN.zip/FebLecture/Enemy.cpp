#include "stdafx.h"
#include "Enemy.h"
#include "Game.h"
#include "GameState.h"
#include "Missile.h"

Enemy::Enemy() : BaseObject(0, 3, "/_\\\n\\ /", System::ConsoleColor::DarkRed, System::ConsoleColor::Black)
{
	SetID(ENEMY);
	SetLife(200);
	SetAlive(true);
}



Enemy::Enemy(int _x, int _y, const char * const _picture, System::ConsoleColor _fg, System::ConsoleColor _bg) : BaseObject(_x, _y, _picture, _fg, _bg)

{
	
	SetY(_y);
	SetX(_x);
	SetPicture(_picture);
	SetFG(_fg);
	SetBG(_bg);
	SetLife(200);
	SetID(ENEMY);
}

Enemy::~Enemy()
{
}

bool Enemy::Input()
{
	
	
	
	return true;
	
	
}

void Enemy::Update(int _frame)
{
	//Could be updated to account for a "speed" variable
	
	//BaseObject** tempObjects = GameState::GetObjects();
	
	//vector<BaseObject*> tempObjects = GameState::GetObjects();

	if (_frame % 10 == 0 && !(GameState::GetSheats() & ENEMY_MOVE))
	{
		vector<BaseObject*>& tempObjects = GameState::GetObjects();
		
		int newX = GetX() + moveDirX;

		int newY = GetY() + moveDirY;

		//Am I about to move out of bounds?  If so, change direction
		if (newX + GetWidth() >= System::Console::WindowWidth() || newX <= 0  )
		{
			moveDirX = -moveDirX;
		}

		if (newY + GetHeight() >= System::Console::WindowHeight() - 2  || newY <= 0 )
		{
			moveDirY = -moveDirY;
		}
		if (_frame % 20 == 0 && !(GameState::GetSheats() & ENEMY_SHOOT))
	
		{


		Missile* m = new Missile();

		m->SetAlive(true);
		m->SetX(GetX() + (GetWidth() >> 1));
		m->SetY(GetY() + GetHeight() - 1);
		m->SetXYVel(0, 1);
		m->SetID(ENEMY_MISSILE);
		tempObjects.push_back(m);
		
		}

		newX = GetX() + moveDirX;
		newY = GetY() + moveDirY;

		
		//Let's do movement here.... shortly.
		

		//Am I moving?
		//	int newX = GetX() + dx;
		//	int newY = GetY() + dy;

			//Check to make sure my potential position is safe to move to
			if (newX + GetWidth() < System::Console::WindowWidth() &&
				newX >= 0
				&&
				(newY + GetHeight() < System::Console::WindowHeight() - 2 ) &&	newY >= 0 )
			{
				bool good = true;
				int i = 0;
				// TODO !!!!!!! change the loop to scale for objects
				//         |
				for (; i < (int)tempObjects.size(); ++i)
				{
					if (this == tempObjects[i])
						continue;
					//if (i == 1) break;
					//TONS of temp variables!  Yeah!
					int myLeft = newX;
					int myRight = newX + GetWidth();
					int theirLeft = tempObjects[i]->GetX();
					int theirRight = tempObjects[i]->GetX() + tempObjects[i]->GetWidth();
					int myTop = newY;
					int myBottom = newY + GetHeight();
					int theirTop = tempObjects[i]->GetY();
					int theirBottom = theirTop + tempObjects[i]->GetHeight();

					if (myRight <= theirLeft ||
						myLeft >= theirRight ||
						myTop >= theirBottom ||
						myBottom <= theirTop)
					{
						//int newX = GetX() + dx;
						//int newY = GetY() + dy;

						
	
						
						//SetX(newX+moveDirX);
						//SetY(newY+moveDirY);
					}
					else
					{
						good = false;
						moveDirY = 1 - (rand() % 2 * 2);
						break;
					}
				}
				if (good)
				{
					SetX(GetX() + moveDirX);
					SetY(GetY() + moveDirY);
				}
			}
	}
}

void Enemy::Render() const
{
	BaseObject::Render();
}

