#pragma once
#include "BaseState.h"

#define ALIVE_FLAG 1
#define POINTS_FLAG 1 << 1
#define ENEMY_MOVE 1 << 2
#define ENEMY_SHOOT 1 << 3
//#define PLAY_SOUND 1 << 4;

class BaseObject;



class GameState :public BaseState
{

	
	//baseState** states;

	//static BaseObject** objects;
	
	static vector<BaseObject*> objects;

	static char cheats;
	

	int level = 1;

public:
GameState();
~GameState();

time_t rawtime;
time_t currentTime;
//static int playTime;
	enum { XStar, YStar };
	int star[15][2];
	int numStarsShow = 15;
	int frameDrag = 0;
virtual bool Input();
//Updates based off input or some sort of frame count
virtual void Update(int _frame);
//Simply displays the object
virtual void Render() const;

virtual void Enter();
virtual void Exit();

//static BaseObject** GetObjects() { return objects; }

static vector<BaseObject*>& GetObjects() { return objects; }

void LoadShip();
void Levels(int _Level);

static char GetSheats() { return cheats; }
static void SetCheats(char cheatsheet) { cheats = cheatsheet; }

void SetLevel(int _level) { level = _level; }
int GetLevel() { return level; }

};

