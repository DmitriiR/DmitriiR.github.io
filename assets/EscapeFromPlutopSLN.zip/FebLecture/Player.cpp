#include "stdafx.h"
#include "Player.h"
#include "Game.h"
#include "GameState.h"

int  W_HIGHT = 40;
int W_WIDTH = 80;



Player::Player(int _x, int _y, const char * const _picture, System::ConsoleColor _fg, System::ConsoleColor _bg,
	int _score, int _diff, const char * const _name) : BaseObject(_x, _y, _picture, _fg, _bg)
{
	//name = NULL;

	SetScore(_score);
	SetDiff(_diff);
	SetName(_name);

	SetID(PLAYER);

}


Player::Player()
{
	SetID(PLAYER);
}


Player::~Player()
{
	//delete[] name;
}


bool Player::Input()
{
	vector<BaseObject*> tempObjects = GameState::GetObjects();
	//BaseObject** tempObjects = GameState::GetObjects();

	if (GetAsyncKeyState(VK_ESCAPE))
	{
		Game::ChangeState(MENU_STATE);
		//return false;
	}

	//Let's do movement here.... shortly.
	int dx, dy;
	dx = dy = 0;

	if (GetAsyncKeyState('W') || GetAsyncKeyState(VK_UP)) dy = -1;
	if (GetAsyncKeyState('S') || GetAsyncKeyState(VK_DOWN)) dy = 1;
	if (GetAsyncKeyState('A') || GetAsyncKeyState(VK_LEFT)) dx = -1;
	if (GetAsyncKeyState('D') || GetAsyncKeyState(VK_RIGHT)) dx = 1;

	//Am I moving?
	if (dx || dy)
	{
		int newX = GetX() + dx;
		int newY = GetY() + dy;

		//Check to make sure my potential position is safe to move to
		if (newX + GetWidth() <= System::Console::WindowWidth() &&
			newX >= 0
			&&
			newY + GetHeight() <= System::Console::WindowHeight() &&
			newY >= 1)
		{
			int i = 1;
			for (; i < 30; ++i)
			{
				//TONS of temp variables!  Yeah!
				int myLeft = newX;
				int myRight = newX + GetWidth();
				int theirLeft = tempObjects[i]->GetX();
				int theirRight = tempObjects[i]->GetX() + tempObjects[i]->GetWidth();
				int myTop = newY;
				int myBottom = newY + GetHeight();
				int theirTop = tempObjects[i]->GetY();
				int theirBottom = theirTop + tempObjects[i]->GetHeight();

				if (myRight <= theirLeft ||
					myLeft >= theirRight ||
					myTop >= theirBottom ||
					myBottom <= theirTop)
				{
					SetX(newX);
					SetY(newY);
				}
				else
				{
					break;
				}
			}
		}
	}

	return true;
}

void Player::Update(int _frame)
{
	if (GameState::GetSheats() && POINTS_FLAG)
	{
		SetScore(GetScore() + 10);
	}

	
}

void Player::Render() const
{
	//Display my HUD
	
	

	// border line
	System::Console::SetCursorPosition(0, W_HIGHT - 2);
	
	for (int i = 0; i < W_WIDTH ; i++)
	{
		cout << (char)205;
	}
	// name display
	System::Console::ForegroundColor(11);
	System::Console::SetCursorPosition(30, W_HIGHT);
	cout << this->GetName();
	System::Console::SetCursorPosition(50, W_HIGHT);


	
	//cout << " Energy "<< this->GetEnergy();


	float currentEnergy = (float)this->GetEnergy();
	float currentMaxEnergy = (float)this->GetMaxEnergy();

	float ratio = currentEnergy / currentMaxEnergy * (float)100.00;
	//cout << ratio;
	System::Console::ForegroundColor(7);
	System::Console::SetCursorPosition(40, W_HIGHT - 2);
	cout << (char)209;
	System::Console::SetCursorPosition(40, W_HIGHT);
	cout << (char)179;
	if (ratio > 50)
	{
		System::Console::ForegroundColor(11);
	}
	else if (ratio > 30)
	{
		System::Console::ForegroundColor(13);
	}

	else if (ratio > 10)
	{
		System::Console::ForegroundColor(5);
	}
	else System::Console::ForegroundColor(4);

	for (int i = 0; i < 20; i++)
	{
		cout << (char)176;
	}
	System::Console::SetCursorPosition(41, W_HIGHT);

	for (int i = 0; i < ratio / 5; i++)
	{
		cout << (char)219;
	}



	System::Console::ForegroundColor(7);
	System::Console::SetCursorPosition(0, W_HIGHT);
	
	cout << "Score: " << this->score;

	float currentlife = (float)this->GetLife();
	float currentmaxlife = (float)this->GetMaxLife();

	ratio = (float)currentlife / (float)currentmaxlife * 100.00f;
	
	//cout << ratio;
	System::Console::ForegroundColor(7);
	System::Console::SetCursorPosition(15, W_HIGHT-2);
	cout << (char)209;
	System::Console::SetCursorPosition(15, W_HIGHT);
	cout << (char)179;
	if (ratio > 50)
	{
		System::Console::ForegroundColor(10);
	}
	else if (ratio > 30) 
	{
		System::Console::ForegroundColor(14);
	}
	
	else if (ratio > 10)
	{
		System::Console::ForegroundColor(12);
	} else System::Console::ForegroundColor(4);
	
	for (int i = 0; i < 10; i++)
	{
		cout << (char)176;
	}


	System::Console::SetCursorPosition(16, W_HIGHT);
	
	for (int i = 0; i < ratio / 10; i++)
	{
		cout << (char)219;
	}

	//System::Console::SetCursorPosition(System::Console::WindowWidth() - 7, 0);
	//cout << "Diff: " << this->diff;

	//Use this to do a simple render, which base object already handles)
	BaseObject::Render();
	

}




//void Player::AskName()
//{

	/*int currY = Console::CursorTop();
	int currX = Console::CursorLeft();
	Console::SetCursorPosition(currX, currY);
	cout << "________________";
	Console::SetCursorPosition(currX, currY);*/
	/*char buffer[64];
	for (;;)
	{
		if (cin.get(buffer, 16))
		{
			cin.sync();
			break;
		}
		cin.clear();
		cin.sync();
	}
	SetName(buffer);*/
	//delete[] name;
	//int len = strlen(buffer) + 1;
	//m_name = new char[len];
	//strcpy_s(m_name, len, buffer);

//}

ostream & operator<<(ostream & _os, PlayerInfo & _info)
{
	_os << _info.name;
	
	for (int i = strlen(_info.name); i < 25; i++)
	{
	_os << " ";
	}
	_os << _info.ship;

	for (int i = strlen(_info.ship); i < 15; i++)
	{
	_os << " ";

	}
	_os << _info.score;
	
	int spaces = 0;
	if (_info.score < 10)
	{
		spaces = 0;
	}
	else if (_info.score < 100)
	{
		spaces = 1;

	}
	else if (_info.score < 1000)
	{
		spaces = 2;

	}
	else if (_info.score < 10000)
	{
		spaces = 3;

	}
	else if (_info.score < 100000)
	{
		spaces = 4;

	}
	else if (_info.score < 1000000)
	{
		spaces = 5;

	}
	for (spaces; spaces < 10; spaces++) { _os << " "; }
	_os << _info.diff << " s";

	
	
	return	_os;
	
}

