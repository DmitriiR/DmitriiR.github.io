#include "stdafx.h"
#include <stdio.h> 
//#include "BaseObject.h"
#include "Game.h"
//#include "Player.h"
//#include "Enemy.h"

#include "Console.h"
#include <fstream>
#include "MenuState.h"
#include "GameState.h"
#include "Cell.h"

#define GAMESPEED 10

//#define SOUND_EFFECTS

// the backgroud music sourse 



BaseState* Game::currentState;
BaseState* Game::states[2];
//Cell * Cell*<>::cells;

//Cell** CellArray = new Cell*[rand() % 11 + 10];


//BaseState * GameState::currentState;

	

Game::Game()
{
	System::Console::EOLWrap(false);
/*
	for (int i = 0; i < 2000; i++)
	{
	time(&timer);
	cout << (int)time << '\n';
	}*/
		
	

	
	states[0] = new MenuState();
	states[1] = new GameState();

	// set up the  game states 
	currentState = NULL;

	ShowStars();

}


Game::~Game()
{
//	delete[] objects;
	int i = 0;
	for (; i < 2; ++i)
		delete states[i];
}

void Game::ChangeState(StateNum _num)
{
	
	if (currentState)
		currentState->Exit();

	currentState = states[_num];
	currentState->Enter();
}





// Primary Play function ----------------------------------------------------------------------------------
void Game::Play()
{
	
	// takes the user to the enter state for the first time, current state ->Enter
	ChangeState(MENU_STATE);

	//if (m_sound) { PlaySound(Audio, NULL, SND_FILENAME | SND_ASYNC | SND_LOOP); }

	// primary play loop
	for (; play; ++frame)
	{
		//System::Console::FlushKeys();
		Input();
		Update(frame); 
		Render();
		Sleep(GAMESPEED);
	}
}

void Game::Input()
{
	////Call input for any objects
	if (!currentState->Input())
	{
		play = false;
	}
}

void Game::Update(int _frame)
{
	//Update any objects
	currentState->Update(_frame);
}

void Game::Render() const
{
	//Simple "back buffering"
	//System::Console::Lock(true);
	//System::Console::Clear();

	////Render any objects
	
	System::Console::Lock(true);
	System::Console::Clear();

	currentState->Render();

	//System::Console::SetCursorPosition(65, 42); 
	//cout << "f: " << frame;
	
	System::Console::Lock(false);

	//float time = GetTime();
	//cout << time; 

#pragma region Old Save Code
#if 0
	fstream fout;
	//fout.open("ships.txt", ios_base::app | ios_base::out | ios_base::binary);
	fout.open("ships.txt", ios_base::out);
	if (fout.is_open())
	{
		fout << 3 << '\n'; //The number of records
		for (i = 0; i < 3; ++i)
		{
			fout << objects[i].GetPicture() << '\t' << objects[i].GetX() << '\t' << objects[i].GetY() << '\t' <<
				objects[i].GetFG() << '\t' << objects[i].GetBG() << '\n';
		}

		fout.close();
	}
#endif
#pragma endregion
}

// reding from and to file  - GAME INITIALIZATION
void Game::PlayerSelection()
{

	
}

void Game::LoadLevel()
{


}

void Game::ShowStars() 
{
	// declare the objects
	int numCells = (rand() % 6 + 5) * 2;
	cells = new Cell<>[numCells];
	for (int i = 0; i < numCells; i++)
	{
		cells[i].sym = '*';
		cells[i].SetFG(System::ConsoleColor(rand() % 15 + 1));
		cells[i].SetBG(System::ConsoleColor(rand() % 15 + 1));
		int tempX = rand() % System::Console::WindowWidth() + 1;
		int tempY = rand() % System::Console::WindowWidth() - 2;
		System::Console::SetCursorPosition(tempX, tempY);
		cells[i].Show(tempX, tempY);

		for (int j = 0; j < numCells; j++)
		{
			// do collision check here... to fix after the linker error 
		}
	}


}

