#include "stdafx.h"
#include "Level.h"


Level::Level() : BaseObject(0, 1, (char*)178, System::ConsoleColor::DarkYellow, System::ConsoleColor::Cyan)
{

}



Level::~Level()
{
}

void Level::Load()
{
	int i = 0;


	// Writing to file 
	// reading from file 
	

	ifstream fin;
	int counter = 0;
	System::Console::SetCursorPosition(25, 20);
	fin.open("level.txt");

	int num = 0;

	if (fin.is_open()) {

		fin >> num;
		BaseObject* tempWall = new BaseObject;
		//BaseObject* levelLine = new BaseObject[100];


		while (!fin.eof()) {
			char output[100];
			int fg, bg;
			fin.ignore(LLONG_MAX, '\n');
			fin.get(output, 100, '\t');
			fin >> fg;
			fin >> bg;

		}
	}
	fin.close();

	system("pause");



}

void Level::SetHealth(int _health)
{
	m_health = _health;
}

int Level::GetHealth()
{
	return m_health;
}
