#include "stdafx.h"
#include "BaseState.h"


BaseState::BaseState()
{
	


}


BaseState::~BaseState()
{
}

bool BaseState::Input()
{
	return true;
}

void BaseState::Update(int _frame)
{


}

void BaseState::Render() const
{

}



void BaseState::Enter()
{
}

void BaseState::Exit()
{
}
