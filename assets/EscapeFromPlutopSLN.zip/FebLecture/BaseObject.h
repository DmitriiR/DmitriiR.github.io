#pragma once
#include "Cell.h"

enum OBJECT_TYPES { BASE = 0, PLAYER, ENEMY, PLAYER_MISSILE, ENEMY_MISSILE };



class BaseObject
{
private:

	// cell array
	vector<Cell<>> arr;
	//char * picture;

	string picture;

	//My X and Y position
	int x, y;

	
	
	
	//Cell * Cell*<>::cells;

	//Width and Height
	int width = -1;
	int height = -1;

	int m_life = 1;
	int m_maxlife = 1;


	//The visual picture on screen of my object
	//char* picture;

	// if the object is alive
	bool alive;
	int lifeTime;
	
	//The colors.  I have nothing else to add to that.
	System::ConsoleColor fg, bg;

	// types of objects
	OBJECT_TYPES id;

public:

	BaseObject();


	//Powerful constructor used to set all data members
	BaseObject(int _x, int _y, char const * const text, System::ConsoleColor foreground, System::ConsoleColor background);
	// overloaded for the bullets
		BaseObject(int _x, int _y, char _picture, System::ConsoleColor _fg, System::ConsoleColor _bg);
	
	//Copy constructor
	BaseObject(BaseObject const& _obj);

	//Assignment operator
	BaseObject& operator=(BaseObject const& _obj);

	//Destructor NOT deconstructor
	virtual ~BaseObject();

	//Accessors	   
	virtual int GetX() const { return x; }
	virtual int GetY() const { return y; }
	const char * const GetText() const { return picture.c_str(); }
	System::ConsoleColor GetFG() const { return fg; }
	System::ConsoleColor GetBG() const { return bg; }
	virtual int GetWidth() const { return width;}
	virtual int GetHeight() const { return height;}
	int GetLife() const { return m_life; }
	int GetMaxLife() const { return m_maxlife; }
	bool GetAlive() const { return alive; }
	int GetLifeTime() const { return lifeTime; }
	OBJECT_TYPES GetID() const { return id; }

	//Mutators
	void SetX(int _x) { x = _x; }
	void SetY(int _y) { y = _y; }
	void SetPicture(const char * const _picture) { picture = _picture; }
	void SetFG(System::ConsoleColor _fg) { fg = _fg;}
	void SetBG(System::ConsoleColor _bg) { bg = _bg; }
	void SetWidth(int _width) { width = _width;}
	void SetHeight(int _height) { height = _height;}
	void SetLife(int _life) { m_life = _life; if (m_life <= 0) alive = false; }
	void SetMaxLife(int _maxlife) { m_maxlife = _maxlife;  }
	void SetAlive(bool _alive) { alive = _alive; }
	void SetLifeTime(int _lifeTime) { lifeTime = _lifeTime; }
	void SetID(OBJECT_TYPES _id) { id = _id; }

	//Function that handles all potential user input
	virtual bool Input();
	
	//Updates based off input or some sort of frame count
	virtual void Update(int _frame);
	
	//Simply displays the object
	virtual void Render() const;

	//Helper function
	virtual void CalcWH();
};

