#pragma once
#include "BaseState.h"


//class BaseObject;


class MenuState : public BaseState
{
private:
	//static BaseObject** objects;
	string strings[3];
	
	//char* strings[3];
	int menuNum = 0;
	int m_numShips = 0;

	bool keyPressed = false;
	bool m_sound = true;

	int choice = 0;
	int pointer = 0;
	int maxShips = 5; // amount of menu items
	int m_ChosenShip; 
	

	int selectedColour = 15;
	int unselectedColour = 8;
	int highlightColour = 8;
	int backgroundColour = 7;

	int currX = 31;
	int currY = 0; // menu initial position

	

public:
	MenuState();
    ~MenuState();
	

	bool Input();
	void Update(int _frame);
	void Render() const;
	
	void Enter();
	void Exit();

	//int HowManyShips();
	void MenuFrame() const;

	void SetShips(int _chosenShip, string _name, bool _empty);
	
	void SetSound(bool _sound) { m_sound = _sound; };
	bool GetSound() { return m_sound; };

	int GetShips();

	void Options();

	void DisplayHighscores();
	
	

	

};

