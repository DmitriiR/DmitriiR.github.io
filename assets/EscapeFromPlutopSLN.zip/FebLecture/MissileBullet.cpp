#include "stdafx.h"
#include "MissileBullet.h"
#include "GameState.h"
#include "Player.h"
#include "Enemy.h"

#define EXPLOSIONSPEED 10

MissileBullet::MissileBullet() : BaseObject(-1, -1, (char)250, System::ConsoleColor::Yellow, System::ConsoleColor::Black)
{
	velVec.resize(2);
	char buff[2];
	sprintf_s(buff, "%c", (char)250);
	SetPicture(buff); // destination, format string - %c character designation %i integer %s string, rest of the parameters can be listed  
	CalcWH();
	SetFG(System::ConsoleColor::Yellow);
	SetBG(System::ConsoleColor::Black);
	SetX(-1);
	SetY(-1);

	SetAlive(false);

}

MissileBullet::~MissileBullet()
{
}


bool MissileBullet::Input()
{
	return true;
}

void MissileBullet::Update(int _frame)
{
	if (GetAlive())
	{
		bool colliding = false;
		//Check collisions
		vector<BaseObject*> tempObjects = GameState::GetObjects();

		decltype(tempObjects.size()) i = 0;
		for (; i < tempObjects.size(); ++i)
		{


			if (tempObjects[i]->GetID() == ENEMY)
			{
				//Checking current XPos instead of updated XPos
				BaseObject* target = tempObjects[i];
				if (GetX() + GetWidth() <= target->GetX() ||
					GetX() > target->GetX() + target->GetWidth() ||
					GetY() > target->GetY() + target->GetHeight() ||
					GetY() + GetHeight() < target->GetY())
				{
					colliding = false;
					continue;
				}
				else
				{
					if (GetID() != ENEMY_MISSILE)
					{
						System::Console::SetCursorPosition(GetX(), GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "*";
						System::Console::SetCursorPosition(GetX() - 1, GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "{ }";
						System::Console::SetCursorPosition(GetX() - 2, GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "(   )";

						target->SetLife(target->GetLife() - GetDamage());

						colliding = false;
						SetAlive(false);
						Player* p = dynamic_cast<Player*>(tempObjects[0]);
						p->SetScore(p->GetScore() + GetLifeTime() + GetDamage()/5);
					}
					break;
				}
			}


			if (tempObjects[i]->GetID() == PLAYER)
			{
				//Checking current XPos instead of updated XPos
				BaseObject* target = tempObjects[i];
				if (GetX() + GetWidth() < target->GetX() ||
					GetX() > target->GetX() + target->GetWidth() ||
					GetY() > target->GetY() + target->GetHeight() ||
					GetY() + GetHeight() < target->GetY())

				{

					colliding = false;

					continue;
				}
				else
				{

					if (GetID() != PLAYER_MISSILE)
					{

						System::Console::SetCursorPosition(GetX(), GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "*";
						System::Console::SetCursorPosition(GetX() - 1, GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "{ }";
						System::Console::SetCursorPosition(GetX() - 2, GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "(   )";


						target->SetLife(target->GetLife() - GetDamage());
						Player* p = dynamic_cast<Player*>(tempObjects[0]);
						p->SetScore(p->GetScore() - this->GetDamage() * 5);
						colliding = false;
						SetAlive(false);

					}
					//Player* p = dynamic_cast<Player*>(tempObjects[0]);
					//p->SetScore(p->GetScore() + 1);

					break;
				}

			}

		}


		int newX = GetX() + velX;
		int newY = GetY() + velY;
		if (newX + GetWidth() <= System::Console::WindowWidth() &&
			newX >= 0
			&&
			newY + GetHeight() <= System::Console::WindowHeight() - 2 &&
			newY >= 1)
		{
			colliding = false;
		}
		else
		{
			colliding = true;
			SetAlive(false);
		}

		if (!colliding)
		{
			SetX(newX);
			SetY(newY);
		}

	}
}

void MissileBullet::Render() const
{
	if (GetAlive())
		BaseObject::Render();

}

void MissileBullet::Explosion()
{
}