#include "stdafx.h"
#include "MenuState.h"
#include "Game.h"
#include "BaseObject.h"
#include "Player.h"
#include "Enemy.h"
#include "GameState.h"
#include <string>
#include <algorithm>
#pragma comment(lib, "Winmm.lib")

#define SLEEP 50
int w_heigh = System::Console::WindowHeight();

/// the backgroud music sourse 
//wchar_t Audio[] = LR"(./Sound/neurotech1.wav)";
//wchar_t AudioSnip[] = LR"(./Sound/NeurotechSnip.wav)";
wchar_t AudioMain[] = LR"(./Sound/NeurotechMain.wav)";


MenuState::MenuState()
{
	strings[0] = "Play";
	strings[1] = "Options";
	strings[2] = "Exit";

}

MenuState::~MenuState()
{

}

bool MenuState::Input()
{

	//Sleep(SLEEP % 10 + 50);
	//System::Console::FlushKeys();

	if (GetAsyncKeyState(VK_UP) != 0 && !keyPressed)
	{
		pointer -= 1;
		if (pointer == -1)
		{
			pointer = maxShips - 1;
		}
		keyPressed = true;
		//break;
	}
	else if (GetAsyncKeyState(VK_DOWN) != 0 && !keyPressed)
	{
		pointer += 1;
		if (pointer == maxShips)
		{
			pointer = 0;
		}
		//break;
		keyPressed = true;
	}

	else if (GetAsyncKeyState(VK_ESCAPE) != 0)
	{

		return false;

	}

	else if (GetAsyncKeyState(VK_RETURN) != 0 && !keyPressed)
	{
		System::Console::ForegroundColor(selectedColour);
		System::Console::BackgroundColor(0);
		System::Console::SetCursorPosition(currX + 1, currY + pointer * 7 + 3);
		cout << (char)214;	for (int t = 0; t < 16; t++) { cout << (char)196; }cout << (char)183;
		System::Console::SetCursorPosition(currX, currY + pointer * 7 + 4);
		//cout << (char)186 << "  " << pointer + 1 << " ships please  ";
		//cout << (char)186;
		System::Console::SetCursorPosition(currX + 1, currY + pointer * 7 + 7);
		cout << (char)211;	for (int t = 0; t < 16; t++) { cout << (char)196; }cout << (char)189;

		
		if (pointer == 3)
		{
			Options();
			
		}

		if (pointer == 4)
		{
			return false;
		}


		if (pointer == 0 || pointer == 1 || pointer == 2)
		{
		
		
		
		System::Console::ForegroundColor(0);
		System::Console::SetCursorPosition(currX + 9, currY + pointer * 7 + 4);
		cout << (char)219 << (char)219 << (char)219;
		System::Console::SetCursorPosition(currX + 7, currY + pointer * 7 + 6);
		cout << (char)219 << (char)219 << (char)219 << (char)219 << (char)219 << (char)219 << (char)219;
		System::Console::ForegroundColor(selectedColour);

		System::Console::SetCursorPosition(currX + 6, currY + pointer * 7 + 3);
		cout << "Call Sign";
		cin.ignore(LLONG_MAX, '\n');
		System::Console::SetCursorPosition(currX +3 , currY + pointer * 7 + 5);
		cout << "______________";
		System::Console::ForegroundColor(11);
		System::Console::FlushKeys();
		//cin.ignore(LLONG_MAX,'\n');

		System::Console::SetCursorPosition(currX + 3, currY + pointer * 7 + 5);
	
		/*for (;;)
		{
			if (cin.get(buffer, 16))
			{
				cin.sync();
				break;
			}
			cin.clear();
			cin.sync();
		}*/
		/*cin.ignore(LLONG_MAX, '\n');
		System::Console::FlushKeys();
		Sleep(SLEEP)*/;
		
		string names;
		//cout << "Enter your name: ";// << flush;
		char input[100];
		cin.getline(input, sizeof(input));
		
		names = input;

		bool empty;
		if (names == "")
		{
			System::Console::SetCursorPosition(currX + 2, currY + pointer * 7 + 5);
			cout << "assigning default\n";
			Sleep(SLEEP*15);
			empty = 1;
			names = "TJ";
		}
		else
		{
			empty = 0;
			System::Console::Clear();
			System::Console::SetCursorPosition(33,14);
			System::Console::ForegroundColor(selectedColour);
			cout << "Welcome, ";
			System::Console::ForegroundColor(11);
			cout << names;// << "for running this simple program!" << endl;

			System::Console::SetCursorPosition(30, 20);
			cout << "Use [ SPACE ] to fire";
			System::Console::ForegroundColor(selectedColour);
			System::Console::SetCursorPosition(40, 18);
			Sleep(SLEEP * 5);
			cout << "3";
			System::Console::SetCursorPosition(40, 18);
			Sleep(SLEEP*5);
			System::Console::SetCursorPosition(40, 18);
			cout << "2";
			System::Console::SetCursorPosition(40, 18);
			Sleep(SLEEP*5);
			cout << "1";
			Sleep(SLEEP * 10);
			System::Console::Clear();


		}
		
	//	names.find("  ", );
		//names.find(names, "  ");


		//std::string str ("There are two needles in this haystack with needles.");
 // std::string str2 ("needle");

  // different member versions of find in the same order as above:
  std::size_t found = names.find(" ");
  if (found!=std::string::npos)
    std::cout << "first 'needle' found at: " << found << '\n';

 /* found=str.find("needles are small",found+1,6);
  if (found!=std::string::npos)
    std::cout << "second 'needle' found at: " << found << '\n';

  found=str.find("haystack");
  if (found!=std::string::npos)
    std::cout << "'haystack' also found at: " << found << '\n';

  found=str.find('.');
  if (found!=std::string::npos)
    std::cout << "Period found at: " << found << '\n';
*/
  // let's replace the first needle:
	 
 // names.replace(names.find("  "),(2),"");
 //cout << " CORRECTONG TO: "<< names  << '\n';


	//	system("pause");

		SetShips(pointer,names,empty);

		
		Game::ChangeState(GAME_STATE);
		}
		//keyPressed = true;
}

	return true;
}

void MenuState::Update(int _frame)
{
	if (!GetAsyncKeyState(VK_UP) || !GetAsyncKeyState(VK_DOWN) ||
		!GetAsyncKeyState(VK_RETURN))
	{
		keyPressed = false;
	}



}

void MenuState::Render() const
{

	//System::Console::BackgroundColor(backgroundColour);
//	System::Console::Lock(true);

	System::Console::Clear();
	System::Console::ForegroundColor(selectedColour);
	MenuFrame();

	//const MenuFrame();

	System::Console::SetCursorPosition((System::Console::WindowWidth() - 33) / 2, System::Console::WindowHeight() - 2);
	cout << " Use your UP/DOWN keys, hit enter ";

	if (pointer == 0)

	{
		System::Console::ForegroundColor(selectedColour);

		System::Console::SetCursorPosition(currX, currY * 3 + 2);
		cout << (char)214 << (char)196 << (char)196 << (char)196 << (char)180 << " ";
		System::Console::ForegroundColor(2);
		cout << "Valkyrie";
		System::Console::ForegroundColor(selectedColour);
		cout << " " << (char)195 << (char)196 << (char)196 << (char)196 << (char)183;
		
		System::Console::SetCursorPosition(currX, currY * 3 + 3);
		cout << (char)186 << "                  " << (char)186;

		System::Console::SetCursorPosition(currX, currY * 3 + 8);
		cout << (char)211;
		cout << "P ";
		System::Console::ForegroundColor(12);
		cout << (char)219;
		System::Console::ForegroundColor(4);
		cout << (char)176;
		System::Console::ForegroundColor(4);
		cout << (char)176;
		
		System::Console::ForegroundColor(selectedColour);
		cout << " T ";
		System::Console::ForegroundColor(14);
		cout << (char)219;
		System::Console::ForegroundColor(14);
		cout << (char)219;
		System::Console::ForegroundColor(6);
		cout << (char)176;
		System::Console::ForegroundColor(selectedColour);
		cout << " Sp ";
		System::Console::ForegroundColor(14);
		cout << (char)219;
		System::Console::ForegroundColor(14);
		cout << (char)219;
		System::Console::ForegroundColor(6);
		cout << (char)176;
		System::Console::ForegroundColor(selectedColour);
		//cout << " ";
		cout << (char)189;

	}
	else
	{
		System::Console::ForegroundColor(unselectedColour);

		
		System::Console::SetCursorPosition(currX, currY * 3 + 2);
		cout << (char)214;	for (int t = 0; t < 18; t++) { cout << (char)196; }cout << (char)183;
	System::Console::SetCursorPosition(currX, currY * 3 + 3);
	cout << (char)186 << "                  " << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 8);
	cout << (char)211;	for (int t = 0; t < 18; t++) { cout << (char)196; }cout << (char)189;
	}

	System::Console::SetCursorPosition(currX, currY * 3 + 4);
	cout << (char)186 << "        / \\       " << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 5);
	cout << (char)186 << "        |^|       " << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 6);
	cout << (char)186 << "       <[|]>      " << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 7);
	cout << (char)186 << "                  " << (char)186;
	

	if (pointer == 1)
	{
		System::Console::ForegroundColor(selectedColour);

		System::Console::SetCursorPosition(currX, currY * 3 + 9);
		cout << (char)214 << (char)196 << (char)196 << (char)196 << (char)196 << (char)180 << " ";
		System::Console::ForegroundColor(4);
		cout << "Falcon";
		System::Console::ForegroundColor(selectedColour);
		cout << " " << (char)195 << (char)196 << (char)196 << (char)196 << (char)196 << (char)183;
		System::Console::SetCursorPosition(currX, currY * 3 + 10);
		cout << (char)186 << "                  " << (char)186;
		
		
		System::Console::SetCursorPosition(currX, currY * 3 + 15);
		
	
		cout << (char)211 << "P ";
		System::Console::ForegroundColor(10);
		cout << (char)219;
		//System::Console::ForegroundColor(14);
		cout << (char)219;
		//System::Console::ForegroundColor(10);
		cout << (char)219;
	
		System::Console::ForegroundColor(selectedColour);
		cout << " T ";
		System::Console::ForegroundColor(10);
		cout << (char)219; 
		//System::Console::ForegroundColor(14);
		cout << (char)219;
		//System::Console::ForegroundColor(10);
		cout << (char)219;

		System::Console::ForegroundColor(selectedColour);
		cout << " Sp ";
		System::Console::ForegroundColor(12);
		cout << (char)219;
		System::Console::ForegroundColor(4);
		cout << (char)176;
		System::Console::ForegroundColor(4);
		cout << (char)176;
		System::Console::ForegroundColor(selectedColour);
		//cout << " ";
		cout << (char)189;
	}

	else
	{

		System::Console::ForegroundColor(unselectedColour);
		System::Console::SetCursorPosition(currX, currY * 3 + 9);
		cout << (char)214;	for (int t = 0; t < 18; t++) { cout << (char)196; }cout << (char)183;
		System::Console::SetCursorPosition(currX, currY * 3 + 10);
		cout << (char)186 << "                  " << (char)186;

		System::Console::SetCursorPosition(currX, currY * 3 + 15);
		cout << (char)211;	for (int t = 0; t < 18; t++) { cout << (char)196; }cout << (char)189;

	}

	System::Console::SetCursorPosition(currX, currY * 3 + 11);
	cout << (char)186 << "        | |       " << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 12);
	cout << (char)186 << "       / ^ \\      " << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 13);
	cout << (char)186 << "      <[|_|]>     " << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 14);
	cout << (char)186 << "                  " << (char)186;
	

	if (pointer == 2)
	{
		System::Console::ForegroundColor(selectedColour);


		System::Console::SetCursorPosition(currX, currY * 3 + 16);
		cout << (char)214 << (char)196 << (char)196 << (char)196 << (char)196 << (char)196 << (char)180 << " ";
		System::Console::ForegroundColor(3);
		cout << "Nemo";
		System::Console::ForegroundColor(selectedColour);
		cout << " " << (char)195 << (char)196 << (char)196 << (char)196 << (char)196 << (char)196 << (char)183;

		System::Console::SetCursorPosition(currX, currY * 3 + 17);
		cout << (char)186 << "                  " << (char)186;


		//System::Console::SetCursorPosition(currX, currY * 3 + 17);
		System::Console::SetCursorPosition(currX, currY * 3 + 22);

		cout << (char)211;
		cout << "P ";
		System::Console::ForegroundColor(12);
		cout << (char)219;
		System::Console::ForegroundColor(4);
		cout << (char)176;
		System::Console::ForegroundColor(4);
		cout << (char)176;

		System::Console::ForegroundColor(selectedColour);
		cout << " T ";
		System::Console::ForegroundColor(12);
		cout << (char)219;
		System::Console::ForegroundColor(4);
		cout << (char)176;
		System::Console::ForegroundColor(4);
		cout << (char)176;
		System::Console::ForegroundColor(selectedColour);
		cout  << " Sp ";
		System::Console::ForegroundColor(10);
		cout << (char)219;
		//System::Console::ForegroundColor(14);
		cout << (char)219;
		//System::Console::ForegroundColor(10);
		cout << (char)219;
		System::Console::ForegroundColor(selectedColour);
		//cout << " ";
		cout << (char)189;


	}
	else
	{
		System::Console::ForegroundColor(unselectedColour);

		System::Console::SetCursorPosition(currX, currY * 3 + 16);
		cout << (char)214;	for (int t = 0; t < 18; t++) { cout << (char)196; }cout << (char)183;
		System::Console::SetCursorPosition(currX, currY * 3 + 17);
		cout << (char)186 << "                  " << (char)186;

		System::Console::SetCursorPosition(currX, currY * 3 + 22);
		cout << (char)211;	for (int t = 0; t < 18; t++) { cout << (char)196; }cout << (char)189;


		//System::Console::SetCursorPosition(currX, currY * 3 + 18);
	}
	
	//cout << (char)186 << "                  " << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 18);
	cout << (char)186 << "                  " << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 19);
	cout << (char)186 << "        / \\       " << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 20);
	cout << (char)186 << "       <[^]>      " << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 21);
	cout << (char)186 << "                  " << (char)186;
	

	if (pointer == 3)

		System::Console::ForegroundColor(selectedColour);
	else
		System::Console::ForegroundColor(unselectedColour);

	System::Console::SetCursorPosition(currX, currY * 3 + 24);
	cout << (char)214;	for (int t = 0; t < 18; t++) { cout << (char)196; }cout << (char)183;
	System::Console::SetCursorPosition(currX, currY * 3 + 25);
	cout << (char)186 << "      OPTIONS     ";
	cout << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 26);
	cout << (char)211;	for (int t = 0; t < 18; t++) { cout << (char)196; }cout << (char)189;

	if (pointer == 4)

		System::Console::ForegroundColor(selectedColour);
	else
		System::Console::ForegroundColor(unselectedColour);

	System::Console::SetCursorPosition(currX, currY * 3 + 27);
	cout << (char)214;	for (int t = 0; t < 18; t++) { cout << (char)196; }cout << (char)183;
	System::Console::SetCursorPosition(currX, currY * 3 + 28);
	cout << (char)186 << "       EXIT       ";
	cout << (char)186;
	System::Console::SetCursorPosition(currX, currY * 3 + 29);
	cout << (char)211;	for (int t = 0; t < 18; t++) { cout << (char)196; }cout << (char)189;

}

// menu initialization code 
void MenuState::Enter()
{

	system("color 00");

	
	// work on this later !!!!!!
	Player Valkyrie(0, 13, " / \\\n |^| \n<[|]>", System::ConsoleColor::White, System::ConsoleColor::Black, 1, 1, "Valkyrie");
	Player Falcon(0, 13, "  | |   \n / ^ \\ \n<[|_|]>", System::ConsoleColor::White, System::ConsoleColor::Black, 1, 1, "Falcon");
	Player Nemo(0, 13, " / \\\n<[^]>", System::ConsoleColor::White, System::ConsoleColor::Black, 1, 1, "Nemo");


	//BaseObject card(1, 1, "+---+\n|A  |\n| \3 |\n|  A|\n+---+", System::ConsoleColor(12), System::ConsoleColor(15)); // Try \x3 instead of H
	//BaseObject dice(1, 10, "* *\n * \n* *", System::ConsoleColor(0), System::ConsoleColor(15));
	//System::Console::SetCursorPosition(0, 3);
	//cout << "Menu State : Enter. Drawing and Loading Ships..\n";

	//cout << "Before:\n";

	//Sleep(SLEEP * 5);

	Valkyrie.SetX(10);
	Valkyrie.SetY(26);
	Valkyrie.SetFG(System::ConsoleColor(10));
	//Valkyrie.Render();// cout << "  " << Valkyrie.GetName() << '\n';
	//Sleep(SLEEP * 5);

	Falcon.SetX(30);
	Falcon.SetY(26);
	Falcon.SetFG(System::ConsoleColor(12));
	//Falcon.Render();// cout << "  " << Falcon.GetName() << '\n';
	//Sleep(SLEEP * 5);

	Nemo.SetX(50);
	Nemo.SetY(26);
	Nemo.SetFG(System::ConsoleColor(11));
	//Nemo.Render();// cout << "  " << Nemo.GetName() << '\n';

	// Writing to file 
	fstream fout;

	fout.open("ships1.txt", ios_base::out);
	if (fout.is_open())
	{
		fout << pointer << '\n';
		fout << 3 << '\n'; //The number of records

		fout << Valkyrie.GetText() << '\t' << Valkyrie.GetX() << '\t' << Valkyrie.GetY() << '\t' <<
			Valkyrie.GetFG() << '\t' << Valkyrie.GetBG() << '\t' << Valkyrie.GetName() << '\n';
//		cout << "\nValkyrie written to file\n";

		fout << Falcon.GetText() << '\t' << Falcon.GetX() << '\t' << Falcon.GetY() << '\t' <<
			Falcon.GetFG() << '\t' << Falcon.GetBG() << '\t' << Falcon.GetName() << '\n';
//		cout << "Falcon written to file\n";

		fout << Nemo.GetText() << '\t' << Nemo.GetX() << '\t' << Nemo.GetY() << '\t' <<
			Nemo.GetFG() << '\t' << Nemo.GetBG() << '\t' << Nemo.GetName() << '\n';
//		cout << "Nemo written to file\n";
//		cout << "Note the enemy ships sets to players selection";
		//fout << dice.GetText() << '\t' << dice.GetX() << '\t' << dice.GetY() << '\t' <<
		//	dice.GetFG() << '\t' << dice.GetBG() << '\n';

		//fout << enemyships[1].GetText() << '\t' << enemyships[1].GetX() << '\t' << enemyships[1].GetY() << '\t' <<
		//	enemyships[1].GetFG() << '\t' << enemyships[1].GetBG() << '\n';

		fout.close();
	}

	// reading from file 

	//fstream fin;
	System::Console::Clear();	
	

	System::Console::DrawBox(29,19, 22,3,false);
	System::Console::SetCursorPosition(30, 22);
	System::Console::ForegroundColor(8);
	cout << "Use ";
	System::Console::ForegroundColor(14);
	cout << "[ENTER]";
	System::Console::ForegroundColor(8);
	cout << " to Select";
	System::Console::SetCursorPosition(28, 23);
	cout << "Use ";
	System::Console::ForegroundColor(14);
	cout << "[ARROW KEYS]";
	System::Console::ForegroundColor(8);
	cout << " to move";
	System::Console::ForegroundColor(8);
	System::Console::SetCursorPosition(30, 20);
	if (m_sound) { PlaySound(AudioMain, NULL, SND_FILENAME | SND_ASYNC | SND_LOOP); }
	
	for (int j = 0; j < 20; j++)
	{
		cout << (char)176;
	}
	System::Console::SetCursorPosition(30, 20);
	System::Console::ForegroundColor(15);

	for (size_t j = 0; j < 20; j++)
	{
		cout << (char)219;
		Sleep(SLEEP);
	}
	
	
	
	
	System::Console::Clear();
	
	//System::Console::SetCursorPosition(22, 16);
	//system("pause");

	System::Console::FlushKeys();
}

void MenuState::Exit()
{
	
}

void MenuState::MenuFrame() const
{
	System::Console::BackgroundColor(0);
	System::Console::ForegroundColor(7);


	cout << (char)201; // the top left edge bend
	for (int i = 0; i < System::Console::WindowWidth() - 2; i++)
	{
		cout << (char)205;// the top line
	}
	cout << (char)187;

	System::Console::SetCursorPosition(0, System::Console::WindowHeight() - 2);
	cout << (char)200; // bottom left bend
	for (int i = 0; i < System::Console::WindowWidth() - 2; i++)
	{
		cout << (char)205;// bottom line
	}
	cout << (char)188; // right boom bend 

	for (int i = 0; i < System::Console::WindowHeight() - 3; i++)
	{
		System::Console::SetCursorPosition(0, System::Console::WindowHeight() - System::Console::WindowHeight() + i + 1);
		cout << (char)186;
		System::Console::SetCursorPosition(System::Console::WindowWidth(), System::Console::WindowHeight() - System::Console::WindowHeight() + i + 1);
		cout << (char)186;
	}

	//for (int i = 0; i < 16; i++)
	//{
	//	System::Console::SetCursorPosition(2, System::Console::WindowHeight() - System::Console::WindowHeight() + i + 1);
	//	System::Console::ForegroundColor(i);
	//	cout << i;

	//}

	//surface
	System::Console::ForegroundColor(8);

	//planet steps

	System::Console::SetCursorPosition(18, 26);
	for (int i = 0; i < System::Console::WindowWidth() - 36; i++)
	{
		cout << (char)177;
	}

	System::Console::SetCursorPosition(10, 27);
	for (int i = 0; i < System::Console::WindowWidth() - 20; i++)
	{
		cout << (char)177;
	}

	System::Console::SetCursorPosition(4, 28);
	for (int i = 0; i < System::Console::WindowWidth() - 8; i++)
	{
		cout << (char)177;
	}

	// planet body
	for (int j = 29; j < System::Console::WindowHeight() - 2; j++)
	{
		System::Console::SetCursorPosition(1, j);

		for (int i = 0; i < System::Console::WindowWidth() - 2; i++)
		{
			cout << (char)177;
		}
	}

	System::Console::ForegroundColor(8);
	System::Console::SetCursorPosition(5, 10);	cout << ".";
	System::Console::SetCursorPosition(7, 5);	cout << ".";
	System::Console::SetCursorPosition(21, 3);	cout << ".";
	System::Console::SetCursorPosition(35, 1);	cout << ".";

	System::Console::SetCursorPosition(62, 3);	cout << ".";
	System::Console::SetCursorPosition(58, 10);	cout << ".";
	System::Console::SetCursorPosition(63, 15);	cout << ".";
	System::Console::SetCursorPosition(73, 20);	cout << ".";
	System::Console::SetCursorPosition(13, 18);	cout << ".";
	System::Console::SetCursorPosition(16, 10);	cout << ".";
	System::Console::SetCursorPosition(3, 22);	cout << ".";
	System::Console::ForegroundColor(7);
	System::Console::SetCursorPosition(73, 17);	cout << ".";


	System::Console::ForegroundColor(15);
	System::Console::SetCursorPosition(5, 10);	cout << ".";
	System::Console::SetCursorPosition(8, 5);	cout << ".";
	System::Console::SetCursorPosition(3, 3);	cout << ".";
	System::Console::SetCursorPosition(28, 1);	cout << ".";

	System::Console::SetCursorPosition(15, 3);	cout << ".";
	System::Console::SetCursorPosition(22, 10);	cout << ".";
	System::Console::ForegroundColor(4);
	System::Console::SetCursorPosition(52, 23);	cout << ".";
	System::Console::SetCursorPosition(10, 16);	cout << ".";

	System::Console::ForegroundColor(15);
	System::Console::SetCursorPosition(56, 3);	cout << "*";
	System::Console::SetCursorPosition(35, 18);	cout << "*";


	System::Console::ForegroundColor(15);
	System::Console::SetCursorPosition(27, 3);	cout << (char)249;
	System::Console::SetCursorPosition(4, 19);	cout << (char)249;
	System::Console::SetCursorPosition(72, 3);	cout << (char)249;
	System::Console::SetCursorPosition(20, 23);	cout << (char)249;

	System::Console::ForegroundColor(8);
	System::Console::SetCursorPosition(67, 6);	cout << "---<O>---";


System::Console::ForegroundColor(3);
System::Console::SetCursorPosition(1, 1);
cout << "                                        $W  \n";
System::Console::SetCursorPosition(1, 2);
cout << "                                        $@~ \n";
System::Console::SetCursorPosition(1, 3);
cout << "                                       ;@@g \n";
System::Console::SetCursorPosition(1, 4);
cout << "                                      ;$@gg \n";
System::Console::SetCursorPosition(1, 5);
cout << "                                     ;$@g"; System::Console::ForegroundColor(11); cout <<"gg \n";
System::Console::SetCursorPosition(1, 6);
System::Console::ForegroundColor(3);
cout << "                                    j$@g"; System::Console::ForegroundColor(11);cout << "gg@ \n";
System::Console::SetCursorPosition(1, 7);
System::Console::ForegroundColor(3);
cout << "                                  -$@@gg"; System::Console::ForegroundColor(11);cout << "gg@ \n";
System::Console::SetCursorPosition(1, 8); System::Console::ForegroundColor(3);
cout << "                                 j$@@gg"; System::Console::ForegroundColor(11);cout << "gggL \n";
System::Console::SetCursorPosition(1, 9); System::Console::ForegroundColor(3);
cout << "                              .;j$@ggg"; System::Console::ForegroundColor(11);cout << "gggN  \n";
System::Console::SetCursorPosition(1, 10); System::Console::ForegroundColor(3);
cout << "                           .;ik$$@gg"; System::Console::ForegroundColor(11);cout << "ggggN   \n";
System::Console::SetCursorPosition(1, 11); System::Console::ForegroundColor(3);
cout << "                       ..;$@@@@@@g"; System::Console::ForegroundColor(11);cout << "gggg@L    \n";
System::Console::SetCursorPosition(1, 12); System::Console::ForegroundColor(3);
cout << "                   .;,;j$Q@@@@@"; System::Console::ForegroundColor(11);cout << "@gggggN      \n";
System::Console::SetCursorPosition(1, 13); System::Console::ForegroundColor(3);
cout << " ..           ,,/p]Q$@@@@@@@"; System::Console::ForegroundColor(11);cout << "@@gggg@P        \n";
System::Console::SetCursorPosition(1, 14); System::Console::ForegroundColor(3);
cout << "   ?gggjKgy@$Q@$@@@@@@@@"; System::Console::ForegroundColor(11);cout << "ggggggg@N(\n";
System::Console::SetCursorPosition(1, 15); System::Console::ForegroundColor(3);
cout << "      J#&@@@@@@ggggg"; System::Console::ForegroundColor(11);cout << "ggggggg@#M \n";
System::Console::SetCursorPosition(1, 16); System::Console::ForegroundColor(3);
cout << "          `)$####%#"; System::Console::ForegroundColor(11);cout << "#####S      \n";



System::Console::ForegroundColor(1);

System::Console::SetCursorPosition(3, 3);
cout << "              U\n";       
System::Console::SetCursorPosition(3, 4);
cout << "             )g\n";
System::Console::SetCursorPosition(3, 5);
cout << "            gg@\n";
System::Console::SetCursorPosition(3, 6);
cout << "          ;gggU\n";
System::Console::SetCursorPosition(3, 7);
cout << "      ,y@@@g@^ \n";
System::Console::SetCursorPosition(3, 8);
cout << "'Vg@g@ggg0D^   \n";
System::Console::SetCursorPosition(3, 9);
cout << "    ^^         \n";












	//System::Console::ForegroundColor(15);
	//System::Console::BackgroundColor(0);
	//System::Console::SetCursorPosition(3, 23);
	//cout << (char)176 << (char)177 << (char)178;

	//System::Console::ForegroundColor(7);
	//System::Console::BackgroundColor(0);
	//System::Console::SetCursorPosition(3, 24);
	//cout << (char)176 << (char)177 << (char)178;

	//System::Console::ForegroundColor(7);
	//System::Console::BackgroundColor(8);
	//System::Console::SetCursorPosition(3, 25);
	//cout << (char)176 << (char)177 << (char)178;

System::Console::SetCursorPosition(3, 30);


	System::Console::BackgroundColor(0);
}

// not used 
void MenuState::SetShips(int _chosenShip, string _name, bool _empty)
{
	m_ChosenShip = _chosenShip;

	fstream fout;

	fout.open("Settings.txt", ios_base::out);
	if (fout.is_open())
	{
		fout << _chosenShip << '\n';
		fout << _name << '\n';
		fout << _empty;
		fout.close();
	}

}

// returns the selected ship of selected ships 
int MenuState::GetShips()
{
	return m_ChosenShip;
}

void MenuState::Options()
{
	
	fstream bing;
	fstream fout;
	fstream bout;

	//int choiceOptions = 0;
	int pointerOptions = 0;
	keyPressed = false;
	bool runOptions = true;
	System::Console::Clear();

	int currYmenu = System::Console::CursorTop();
	int currXmenu = System::Console::CursorLeft();

	MenuFrame();
	
	while (runOptions)
	{
		//System::Console::Clear();
		System::Console::Lock(true);
		System::Console::FlushKeys();
		
		
		//Sleep(SLEEP);
		System::Console::ForegroundColor(8);

		System::Console::DrawBox(0, 0, 80, 39, true);
		System::Console::SetCursorPosition(52, 8);
		cout << "Options";
		System::Console::SetCursorPosition(22, 39);
		cout << "Use your UP/DOWN keys, hit enter ";

		System::Console::SetCursorPosition(25, 37);
		cout << "Press [i] for info";
		//System::Console::Lock(false);

		//System::Console::Lock(false);



		//for (int i = 0; i < 4; i++)
	//	{
			//System::Console::Lock(true);
			//System::Console::Clear();
			if (pointerOptions == 0)
			{
				System::Console::SetCursorPosition(52,10);
				System::Console::ForegroundColor(14);
				cout << "<HighScores>";
			}
			else 
			{
				System::Console::SetCursorPosition(52, 10);
				System::Console::ForegroundColor(8);
				cout << " HighScores ";
			}
			
			if (pointerOptions == 1)
			{
				System::Console::SetCursorPosition(52, 12);
				System::Console::ForegroundColor(14);
				cout << "<Sound>";
			}
			else
			{
				System::Console::SetCursorPosition(52, 12);
				System::Console::ForegroundColor(8);
				cout << " Sound ";
				System::Console::ForegroundColor(11);
			
					if (GetSound() == 1)
					{
						cout << " ON  ";
					} else
						cout << " OFF  ";
			}
			
			if (pointerOptions == 2)
			{
				System::Console::SetCursorPosition(52, 14);
				System::Console::ForegroundColor(14);
				cout << "<Reset High Scores> ";
			}
			else
			{
				System::Console::SetCursorPosition(52, 14);
				System::Console::ForegroundColor(8);
				cout << " Reset High Scores ";
			}

		
			if (pointerOptions == 3)
			{
				System::Console::SetCursorPosition(52, 16);
				System::Console::ForegroundColor(14);
				cout << "<Readme/Help>";
			}
			else
			{
				System::Console::SetCursorPosition(52, 16);
				System::Console::ForegroundColor(8);
				cout << " Readme/Help ";
			}

			if (pointerOptions == 4)
			{
				System::Console::SetCursorPosition(52, 18);
				System::Console::ForegroundColor(14);
				cout << "<Force NUMBER SIX>";
			}
			else
			{
				System::Console::SetCursorPosition(52, 18);
				System::Console::ForegroundColor(8);
				cout << " Force NUMBER SIX ";
			}

			if (pointerOptions == 5)
			{
				System::Console::SetCursorPosition(52, 20);
				System::Console::ForegroundColor(14);
				cout << "<Back> ";
			}
			else
			{
				System::Console::SetCursorPosition(52, 20);
				System::Console::ForegroundColor(8);
				cout << " Back ";
			}

			System::Console::Lock(false);

			while (runOptions)
			{
				if (GetAsyncKeyState(VK_UP) != 0 && !keyPressed)
				{
					pointerOptions -= 1;
					if (pointerOptions == -1)
					{
						pointerOptions = 5;
					}
					keyPressed = true;
					break;
				}
				else if (GetAsyncKeyState(VK_DOWN) != 0 && !keyPressed)
				{
					pointerOptions += 1;
					if (pointerOptions == 6)
					{
						pointerOptions = 0;
					}
					keyPressed = true;
					break;
				}

				else if (GetAsyncKeyState(VK_ESCAPE) != 0  && !keyPressed)
				{
					runOptions = false;
					keyPressed = true;
					break;
				}
				else if (GetAsyncKeyState('I') != 0 && !keyPressed)
				{
					pointerOptions = 3;

					keyPressed = true;
					break;
				}

				else if (GetAsyncKeyState(0x49) != 0 && !keyPressed)
				{


					keyPressed = true;
					break;
				}

				else if (GetAsyncKeyState(VK_RETURN) != 0 && !keyPressed || GetAsyncKeyState('I') != 0)
				{
					keyPressed = true;
					switch (pointerOptions)
					{
					case 0: // show scores 
						System::Console::FlushKeys();
						Sleep(SLEEP);
						DisplayHighscores();

						MenuFrame();
						break;
					case 1: 

						SetSound(!GetSound());
						System::Console::FlushKeys();
						System::Console::SetCursorPosition(52, 12);
						System::Console::ForegroundColor(4);
						cout << " Sound ";
						System::Console::ForegroundColor(11);

						if (GetSound() == 1)
						{
							cout << " ON  ";
						}
						else
							cout << " OFF  ";
						//if (m_sound) { PlaySound(AudioSnip, NULL, SND_FILENAME | SND_ASYNC); }

						if (m_sound) { PlaySound(AudioMain, NULL, SND_FILENAME | SND_ASYNC | SND_LOOP); }
						//PlaySound(TEXT("MyAppSound"), NULL, SND_APPLICATION);
						if (!m_sound) { PlaySound(NULL, NULL, SND_FILENAME | SND_ASYNC | SND_LOOP); }
						
						Sleep(SLEEP);
						break;
					case 2: // reseting scores 
						//cout << "reading from file \n";
						bing.open("scores.bin", ios_base::binary | ios_base::trunc | ios_base::out);
						if (bing.is_open())
						{
							//bing.open("scores.bin", ios_base::binary | ios_base::trunc );
							//System::Console::SetCursorPosition();
							System::Console::SetCursorPosition(52, 14);
							System::Console::ForegroundColor(13);
							cout << "       RESET           ";
						
							
							
						}
						Sleep(SLEEP * 5);
						bing.close();
						break;
					case 3: // about 
						System::Console::Clear();
						System::Console::SetCursorPosition(3,10);
						System::Console::ForegroundColor(8);
						cout << "Hi, Welcome to Escape From Pluto";
						
						System::Console::SetCursorPosition(3, 12);
						System::Console::ForegroundColor(15);
						cout << "Controls :";

						System::Console::SetCursorPosition(3, 14);
						System::Console::ForegroundColor(7);
						cout << "Use the [arrows] and [SPACE],\nThe game will advance once all the enemies are dead.\n\n\n";

						System::Console::SetCursorPosition(3, 15);
						System::Console::ForegroundColor(7);
						cout << "In-game cheats are activated with the F1, F2, F3 keys.\n";
						cout << "Score is calculated with the lifetime and damage combined\n";
						cout << "When you get hit, you lose points and life";
						cout << "Written by Dmitrii Zrianov 2014\n";
						

						cout << "\n\n";
						system("pause");
						System::Console::Clear();

						MenuFrame();

						break;
	
					case 4: // writing Number six
						
						PlayerInfo tempInfo;

						bing.open("scores.bin", ios_base::binary | ios_base::app | ios_base::in);
						if (bing.is_open())
						{
							//bing.open("scores.bin", ios_base::binary | ios_base::trunc );
							System::Console::SetCursorPosition(52, 18);
							System::Console::ForegroundColor(13);
							cout << "       WRITING        ";
							Sleep(SLEEP);

							bing.seekg(0, ios_base::end);
							//bing.clear();
							int size = (int)bing.tellg();
							size /= sizeof(PlayerInfo);
							if (size >=  6)
							{
									bing.seekg(5 * sizeof(PlayerInfo), ios_base::beg);
									bing.read((char*)&tempInfo, sizeof(PlayerInfo));
					
									
									strcpy_s(tempInfo.name, 11,"NUMBER 6");
							
									

									bout.open("scores.bin", ios_base::binary | ios_base::out | ios_base::in);
									if (bout.is_open())
										{

											bout.seekp(5 * sizeof(PlayerInfo), ios_base::beg);
											bout.write((char*)&tempInfo, sizeof(PlayerInfo));
											bout.close();
										}

							}
							//scores.resize(0);
							//bing.read((char*)&scores[0], sizeof(PlayerInfo) * size);

						}

						System::Console::Clear();

						MenuFrame();

						System::Console::FlushKeys();
						break;

					case 5: // exit
						runOptions = false;
						System::Console::Clear();

						MenuFrame();
						System::Console::FlushKeys();
						break;
					case 6:
						break;
					}
					break;
				}
				if (!GetAsyncKeyState(VK_RETURN) && !GetAsyncKeyState(VK_UP) && !GetAsyncKeyState(VK_DOWN))
				{
					keyPressed = false;
				}
			//System::Console::Lock(true);
			//keyPressed = false;
			//	System::Console::Lock(false);

			}
			System::Console::Lock(false);

	}
	
	Sleep(SLEEP % 10+100);
	System::Console::FlushKeys();
	//Display the high scores
	pointer = 3;
	keyPressed = false;
	System::Console::Clear();
}


void MenuState::DisplayHighscores()
{

	System::Console::Clear();
	Sleep(SLEEP+100);

	vector<PlayerInfo> scores;

	//Read in from the binary file
	fstream bing;
	fstream fout;
	string fileName;

	bing.open("scores.bin", ios_base::binary | ios_base::in);
	if (bing.is_open())
	{
		bing.seekg(0, ios_base::end);
		int size = (int)bing.tellg();
		size /= sizeof(PlayerInfo);
		bing.seekg(0, ios_base::beg);
		scores.resize(size);
		if (size != 0 ) bing.read((char*)&scores[0], sizeof(PlayerInfo) * size);
		bing.close();
	}
	
	int sortType = 0;
	bool runScores = true;
	pointer = 1;
	keyPressed = true;
	bool initenterence = true;
	int currentSort = 1;
	
	while (runScores)
	{
	
			int averageScore = 0;
			int averageTime = 0;
			int maxScore = 0;
			int minScore = 0;

		//System::Console::Clear();
		System::Console::Lock(false);
		System::Console::FlushKeys();
		System::Console::ForegroundColor(8);
		System::Console::DrawBox(0,0,80,39,false);

		System::Console::SetCursorPosition(24, 29);
		cout << "total of " << scores.size() << " scores, showing top 20";

		System::Console::SetCursorPosition(24, 33);
		cout << "Press S to save to text file";

		System::Console::SetCursorPosition(22, 39);
		cout << "Use your LEFT/RIGHT keys, hit enter ";
		
		for (int i = 0; i <= 4; i++)
		{
			if (pointer == 0)
			{
				System::Console::SetCursorPosition(7, 35);
				System::Console::ForegroundColor(14);
				cout << "<BACK> ";
			}
			else
			{
				System::Console::SetCursorPosition(7, 35);
				System::Console::ForegroundColor(8);
				cout << " BACK ";
			}
			
			if (pointer == 1)
			{
				System::Console::SetCursorPosition(22, 35);
				System::Console::ForegroundColor(14);
				cout << "<Scores 9-1>";
			}
			else
			{
				if (currentSort == 1)
				{
				System::Console::ForegroundColor(6);

				}else
					System::Console::ForegroundColor(8);
				
				System::Console::SetCursorPosition(22, 35);
				cout << " Scores 9-1 ";
			}

			if (pointer == 2)
			{
				System::Console::SetCursorPosition(37, 35);
				System::Console::ForegroundColor(14);
				cout << "<Scores 1-9>";
			}
			else
			{
				System::Console::SetCursorPosition(37, 35);
				if (currentSort == 2)
				{
					System::Console::ForegroundColor(6);

				}
				else
					System::Console::ForegroundColor(8);
				cout << " Scores 1-9 ";
			}

			if (pointer == 3)
			{
				System::Console::SetCursorPosition(52, 35);
				System::Console::ForegroundColor(14);
				cout << "<Name A-Z>";
			}
			else
			{
				System::Console::SetCursorPosition(52, 35);
				if (currentSort == 3)
				{
					System::Console::ForegroundColor(6);

				}
				else
					System::Console::ForegroundColor(8);
				cout << " Name A-Z ";
			}

			if (pointer == 4)
			{
				System::Console::SetCursorPosition(67, 35);
				System::Console::ForegroundColor(14);
				cout << "<Name Z-A>";
			}
			else
			{
				System::Console::SetCursorPosition(67, 35);
				if (currentSort == 4)
				{
					System::Console::ForegroundColor(6);

				}
				else
					System::Console::ForegroundColor(8); 
				cout << " Name Z-A ";
			}

			
			int saveRecords = 0;
			while (runScores )
			{
				// if they save
				if (GetAsyncKeyState('S') != 0 && !keyPressed)
				{
					// save to file;
					System::Console::Clear();
					System::Console::FlushKeys();
					System::Console::SetCursorPosition(10,20);
					System::Console::ForegroundColor(8);
					cout << "How many records would you like to save? (0 - "<< (int)scores.size() << ") :";
					System::Console::ForegroundColor(14);
					cin >> saveRecords;
					
					System::Console::SetCursorPosition(10, 21);
					System::Console::ForegroundColor(8);
					cout << "File name to use _______________.txt";
					cin.ignore(LLONG_MAX, '\n');
					System::Console::ForegroundColor(14);
					System::Console::SetCursorPosition(27, 21);
					//cin >> fileName;

					string names;
				//	bool empty;
					//cout << "Enter your name: ";// << flush;
					char input[100];
					cin.getline(input, sizeof(input));

					fileName = input;

					
					fileName = fileName + ".txt";

					
					keyPressed = true;
					/// sort and save functions 					
					

				
					int lineCounter = 5;
					keyPressed = true;
					int numScoresToList = 0;
					
					initenterence = false; // initial enterence varible 
					switch (pointer)
					{
					case 0:
						runScores = false;
						System::Console::Clear();
						System::Console::FlushKeys();
						pointer = 0;

						break;
					case 1: // Score 9-1
						currentSort = 1;

						
						System::Console::SetCursorPosition(9, lineCounter);
						System::Console::ForegroundColor(7);			  // print out content:

						for (int j = 0; j < (int)scores.size() - 1; ++j)
						{

							for (int k = j + 1; k < (int)scores.size(); k++)
							{
								if (scores[k].score > scores[j].score)
								{
									swap(scores[k], scores[j]);
								}
							}
						}

						// Writing to file

						
						fout.open(fileName, ios_base::out);
						if (fout.is_open())
						{
							for (int j = 0; j < (int)scores.size() && j < saveRecords; ++j)
							{
								fout << scores[j].name << '\t' << scores[j].ship << '\t' << scores[j].score << '\t' << scores[j].diff << '\n';
								cout << scores[j].name << '\t' << scores[j].ship << '\t' << scores[j].score << '\t' << scores[j].diff << '\n';

							}

							fout.close();
						}

						cout << "\n\nrecord written\n\n\n ";
						system("pause");
						System::Console::Clear();
						break;
					case 2: // score 1-9
						currentSort = 2;

						System::Console::SetCursorPosition(9, lineCounter);
						System::Console::ForegroundColor(7);													   // print out content:

						for (int j = 0; j < (int)scores.size() - 1; ++j)
						{

							for (int k = j + 1; k < (int)scores.size(); k++)
							{
								if (scores[k].score < scores[j].score)
								{
									swap(scores[k], scores[j]);
								}
							}
						}


						// Writing to file


						fout.open(fileName, ios_base::out);
						if (fout.is_open())
						{
							for (int j = 0; j < (int)scores.size() && j < saveRecords; ++j)
							{
								fout << scores[j].name << '\t' << scores[j].ship << '\t' << scores[j].score << '\t' << scores[j].diff << '\n';
								cout << scores[j].name << '\t' << scores[j].ship << '\t' << scores[j].score << '\t' << scores[j].diff << '\n';

							}

							fout.close();
						}

						cout << "\n\nrecord written\n\n\n ";
						system("pause");
						System::Console::Clear();

						break;
					case 3: // name A - Z
						currentSort = 3;
						for (int j = 0; j < (int)scores.size() - 1; ++j)
						{

							for (int k = j + 1; k < (int)scores.size(); k++)
							{
								if ((strcmp(scores[k].name, scores[j].name)) == -1)
								{
									swap(scores[k], scores[j]);
								}
							}
						}

						System::Console::SetCursorPosition(9, lineCounter);
						System::Console::ForegroundColor(7);													   // print out content:

																												   // Writing to file


						fout.open(fileName, ios_base::out);
						if (fout.is_open())
						{
							for (int j = 0; j < (int)scores.size() && j < saveRecords; ++j)
							{
								fout << scores[j].name << '\t' << scores[j].ship << '\t' << scores[j].score << '\t' << scores[j].diff << '\n';
								cout << scores[j].name << '\t' << scores[j].ship << '\t' << scores[j].score << '\t' << scores[j].diff << '\n';

							}

							fout.close();
						}

						cout << "\n\nrecord written\n\n\n ";
						system("pause");
						System::Console::Clear();

						break;

					case 4: // names Z -A
						currentSort = 4;
						for (int j = 0; j < (int)scores.size() - 1; ++j)
						{

							for (int k = j + 1; k < (int)scores.size(); k++)
							{
								if ((strcmp(scores[k].name, scores[j].name)) == 1)
								{
									swap(scores[k], scores[j]);
								}
							}
						}

						// Writing to file


						fout.open(fileName, ios_base::out);
						if (fout.is_open())
						{
							for (int j = 0; j < (int)scores.size() && j < saveRecords; ++j)
							{
								fout << scores[j].name << '\t' << scores[j].ship << '\t' << scores[j].score << '\t' << scores[j].diff << '\n';
								cout << scores[j].name << '\t' << scores[j].ship << '\t' << scores[j].score << '\t' << scores[j].diff << '\n';
							}
							fout.close();
						}

						cout << "\n\nrecord written\n\n\n ";
						system("pause");
						System::Console::Clear();
						//cout << "\n\ntotal of " << scores.size() << " scores, showing top 20";
						break;

					}
					break;
				



					
					break;
				}

				if (GetAsyncKeyState(VK_LEFT) != 0 && !keyPressed)
				{
					pointer -= 1;
					if (pointer == -1)
					{
						pointer = 4;
					}
					keyPressed = true;
					break;
				}
				else if (GetAsyncKeyState(VK_RIGHT) != 0 && !keyPressed)
				{
					pointer += 1;
					if (pointer == 5)
					{
						pointer = 0;
					}
					keyPressed = true;
					break;
				}

				else if (GetAsyncKeyState(VK_ESCAPE) != 0 && !keyPressed)
				{

					keyPressed = true;
					runScores = false;
					System::Console::Clear();
					System::Console::FlushKeys();
					pointer = 0;

					break;
				}

				else if (GetAsyncKeyState(0x49) != 0 && !keyPressed)
				{

					runScores = false;
					System::Console::Clear();
					System::Console::FlushKeys();
					keyPressed = true;
					break;
				}

				else if (GetAsyncKeyState(VK_RETURN) != 0 && !keyPressed || initenterence)
				{
					int lineCounter = 5;
					keyPressed = true;
					int numScoresToList = 0;
				
					initenterence = false; // initial enterence varible 
					switch (pointer)
					{
					case 0:
						runScores = false;
						System::Console::Clear();
						System::Console::FlushKeys();
						pointer = 0;

						break;
					case 1: // Score 9-1
						if (scores.size() != 0)
						{


							currentSort = 1;
							System::Console::SetCursorPosition(9, lineCounter);
							System::Console::ForegroundColor(7);			  // print out content:

							for (int j = 0; j < (int)scores.size() - 1; ++j)
							{
								for (int h = 0; h < (int)scores.size() - 1; ++h)
								{
									if (scores[h].score > maxScore)
									{
										maxScore = scores[h].score;
									}
								}
								minScore = 100000000;
								for (int h = 0; h < (int)scores.size() - 1; ++h)
								{
									if (scores[h].score < minScore)
									{
										minScore = scores[h].score;
									}
								}


								for (int k = j + 1; k < (int)scores.size(); k++)
								{
									if (scores[k].score > scores[j].score)
									{
										swap(scores[k], scores[j]);
									}
								}
							}


							cout << "-----------------=========== SCORES 9 - 1 =======-------------\n";
							cout << "          Name                     Ship          Score      Time";
							for (vector<PlayerInfo>::iterator it = scores.begin(); (it != scores.end() && numScoresToList < 20); ++it)
							{
								System::Console::ForegroundColor(8);
								System::Console::SetCursorPosition(6, lineCounter++ + 4);
								if (numScoresToList < 9)
								{
									cout << numScoresToList + 1 << ".   ";
								}
								else cout << numScoresToList + 1 << ".  ";
								cout << *it << "  ";

								/*if (numScoresToList == 5)
								{
									strcpy_s(it->name, 9, "NUMBER 6");

								}*/

								averageScore = averageScore + it->score;
								averageTime = averageTime + it->diff;

								numScoresToList++;
							}
							System::Console::SetCursorPosition(24, 30);
							cout << "Average score: ";
							System::Console::ForegroundColor(15);
							cout << averageScore / scores.size();
							System::Console::ForegroundColor(8);
							System::Console::SetCursorPosition(25, 31);
							cout << "Average time: ";
							System::Console::ForegroundColor(15);
							cout << averageTime / scores.size() << "s";
							averageScore = 0;
							averageTime = 0;

							System::Console::ForegroundColor(8);
							System::Console::SetCursorPosition(50, 30);
							cout << "Max score: ";
							System::Console::ForegroundColor(15);
							cout << maxScore;
							System::Console::ForegroundColor(8);
							System::Console::SetCursorPosition(50, 31);
							cout << "Min Score: ";
							System::Console::ForegroundColor(15);
							cout <<minScore;
							
							maxScore = 0;
							minScore = 0;

						}
						else
						{
							System::Console::SetCursorPosition(24, 13);
							cout << "No Scores to list";
						}

						//cout << "\n\ntotal of " << scores.size() << " scores, showing top 20";
						break; 
					case 2: // score 1-9
						if (scores.size() != 0)
						{
							currentSort = 2;

							System::Console::SetCursorPosition(9, lineCounter);
							System::Console::ForegroundColor(7);													   // print out content:

							for (int j = 0; j < (int)scores.size() - 1; ++j)
							{
								for (int h = 0; h < (int)scores.size() - 1; ++h)
								{
									if (scores[h].score > maxScore)
									{
										maxScore = scores[h].score;
									}
								}
								minScore = 100000000;
								for (int h = 0; h < (int)scores.size() - 1; ++h)
								{
									if (scores[h].score < minScore)
									{
										minScore = scores[h].score;
									}
								}
								for (int k = j + 1; k < (int)scores.size(); k++)
								{
									if (scores[k].score < scores[j].score)
									{
										swap(scores[k], scores[j]);
									}
								}
							}


							cout << "-----------------========= SCORES 1 - 9 ==========-------------\n";
							cout << "          Name                     Ship          Score      Time";
							for (vector<PlayerInfo>::iterator it = scores.begin(); (it != scores.end() && numScoresToList < 20); ++it)
							{
								System::Console::ForegroundColor(8);
								System::Console::SetCursorPosition(6, lineCounter++ + 4);
								if (numScoresToList < 9)
								{
									cout << numScoresToList + 1 << ".   ";
								}
								else cout << numScoresToList + 1 << ".  ";
								cout << *it << "  ";

								/*if (numScoresToList == 5)
								{
									strcpy_s(it->name, 9, "NUMBER 6");

								}*/

								averageScore = averageScore + it->score;
								averageTime = averageTime + it->diff;
								numScoresToList++;
							}
							System::Console::SetCursorPosition(24, 30);
							cout << "Average score: ";
							System::Console::ForegroundColor(15);
							cout << averageScore / scores.size();
							System::Console::ForegroundColor(8);
							System::Console::SetCursorPosition(25, 31);
							cout << "Average time: ";
							System::Console::ForegroundColor(15);
							cout << averageTime / scores.size() << "s";
							averageScore = 0;
							averageTime = 0;

							System::Console::ForegroundColor(8);
							System::Console::SetCursorPosition(50, 30);
							cout << "Max score: ";
							System::Console::ForegroundColor(15);
							cout << maxScore;
							System::Console::ForegroundColor(8);
							System::Console::SetCursorPosition(50, 31);
							cout << "Min Score: ";
							System::Console::ForegroundColor(15);
							cout << minScore;

							maxScore = 0;
							minScore = 0;

							//cout << "\n\ntotal of " << scores.size() << " scores, showing top 20" ;
						}
						else
						{
							System::Console::SetCursorPosition(24, 13);
							cout << "No Scores to list";
						}

						break;
					case 3: // name A - Z
						if (scores.size() != 0)
						{
						currentSort = 3;
						for (int j = 0; j < (int)scores.size() - 1; ++j)
						{
							for (int h = 0; h < (int)scores.size() - 1; ++h)
							{
								if (scores[h].score > maxScore)
								{
									maxScore = scores[h].score;
								}
							}
							minScore = 100000000;
							for (int h = 0; h < (int)scores.size() - 1; ++h)
							{
								if (scores[h].score < minScore)
								{
									minScore = scores[h].score;
								}
							}
							for (int k = j + 1; k < (int)scores.size(); k++)
							{
								if ((strcmp(scores[k].name, scores[j].name)) == -1)
								{
									swap(scores[k], scores[j]);
								}
							}
						}

						System::Console::SetCursorPosition(9, lineCounter);
						System::Console::ForegroundColor(7);													   // print out content:

						cout << "-----------------=========== Names A - Z ========-------------\n";
						cout << "          Name                     Ship          Score      Time";
						for (vector<PlayerInfo>::iterator it = scores.begin(); (it != scores.end() && numScoresToList < 20); ++it)
						{
							System::Console::ForegroundColor(8);
							System::Console::SetCursorPosition(6, lineCounter++ + 4);
							if (numScoresToList < 9)
							{
								cout << numScoresToList + 1 << ".   ";
							}
							else cout << numScoresToList + 1 << ".  ";
							cout << *it << "  ";
							/*if (numScoresToList == 5)
							{
								strcpy_s(it->name, 9, "NUMBER 6");

							}*/
							averageScore = averageScore + it->score;
							averageTime = averageTime + it->diff;
							numScoresToList++;
						}
						System::Console::SetCursorPosition(24, 30);
						cout << "Average score: ";
						System::Console::ForegroundColor(15);
						cout << averageScore / scores.size();
						System::Console::ForegroundColor(8);
						System::Console::SetCursorPosition(25, 31);
						cout << "Average time: ";
						System::Console::ForegroundColor(15);
						cout << averageTime / scores.size() << "s";
						averageScore = 0;
						averageTime = 0;

						System::Console::ForegroundColor(8);
						System::Console::SetCursorPosition(50, 30);
						cout << "Max score: ";
						System::Console::ForegroundColor(15);
						cout << maxScore;
						System::Console::ForegroundColor(8);
						System::Console::SetCursorPosition(50, 31);
						cout << "Min Score: ";
						System::Console::ForegroundColor(15);
						cout << minScore;

						maxScore = 0;
						minScore = 0;

						}
						else
						{
							System::Console::SetCursorPosition(24, 13);
							cout << "No Scores to list";
						}
					//	cout << "\n\ntotal of " << scores.size() << " scores, showing top 20";

						break;

					case 4: // names Z -A
						if (scores.size() != 0)
						{
						currentSort = 4;
						for (int j = 0; j < (int)scores.size() - 1; ++j)
						{
							for (int h = 0; h < (int)scores.size() - 1; ++h)
							{
								if (scores[h].score > maxScore)
								{
									maxScore = scores[h].score;
								}
							}
							minScore = 100000000;
							for (int h = 0; h < (int)scores.size() - 1; ++h)
							{
								if (scores[h].score < minScore)
								{
									minScore = scores[h].score;
								}
							}
							for (int k = j + 1; k < (int)scores.size(); k++)
							{
								if ((strcmp(scores[k].name, scores[j].name)) == 1)
								{
									swap(scores[k], scores[j]);
								}
							}
						}

						System::Console::SetCursorPosition(9, lineCounter);
						System::Console::ForegroundColor(7);													   // print out content:

						cout << "-----------------=========== Names Z - A ========-------------\n";
						cout << "          Name                     Ship          Score      Time";
						for (vector<PlayerInfo>::iterator it = scores.begin(); (it != scores.end() && numScoresToList < 20); ++it)
						{
							System::Console::ForegroundColor(8);
							System::Console::SetCursorPosition(6, lineCounter++ + 4);
							if (numScoresToList < 9)
							{
								cout << numScoresToList + 1 << ".   ";
							}
							else cout << numScoresToList + 1 << ".  ";
							cout << *it << "  ";
							
							/*if (numScoresToList == 5)
							{
								strcpy_s(it->name, 9, "NUMBER 6");

							}*/
							averageScore = averageScore + it->score;
							averageTime = averageTime + it->diff;
							numScoresToList++;
						}
						System::Console::SetCursorPosition(24, 30);
						cout << "Average score: ";
						System::Console::ForegroundColor(15);
						cout << averageScore / scores.size();
						System::Console::ForegroundColor(8);
						System::Console::SetCursorPosition(25, 31);
						cout << "Average time: ";
						System::Console::ForegroundColor(15);
						cout << averageTime / scores.size() << "s";
						averageScore = 0;
						averageTime = 0;

						System::Console::ForegroundColor(8);
						System::Console::SetCursorPosition(50, 30);
						cout << "Max score: ";
						System::Console::ForegroundColor(15);
						cout << maxScore;
						System::Console::ForegroundColor(8);
						System::Console::SetCursorPosition(50, 31);
						cout << "Min Score: ";
						System::Console::ForegroundColor(15);
						cout << minScore;

						maxScore = 0;
						minScore = 0;

						}
						else
						{
							System::Console::SetCursorPosition(24, 13);
							cout << "No Scores to list";
						}
						//cout << "\n\ntotal of " << scores.size() << " scores, showing top 20";
						break;

					}
					break;
				}

				if (!GetAsyncKeyState(VK_RETURN) && !GetAsyncKeyState(VK_LEFT) && !GetAsyncKeyState(VK_RIGHT))
				{
					keyPressed = false;
				}

				

			} // while run loop 
		} // for menu items loop 
	} // while menu run loop
			System::Console::Clear();
			System::Console::FlushKeys();
					//System::Console::Lock(true);
					//keyPressed = false;
			Sleep(SLEEP % 10 + 100);
}
			




	


