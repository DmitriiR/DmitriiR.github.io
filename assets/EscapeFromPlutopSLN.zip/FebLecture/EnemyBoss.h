#pragma once
#include "BaseObject.h"
#include "Player.h"
class EnemyBoss :	public BaseObject
{
private:
	int moveDirX = -1;
	int moveDirY = -1;

public:
	EnemyBoss();
~EnemyBoss();

EnemyBoss(int _x, int _y, const char * const _picture, System::ConsoleColor _fg, System::ConsoleColor _bg);

bool Input();
void Update(int _frame);
void Render() const;

};





