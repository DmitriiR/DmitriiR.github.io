// FebLecture.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Game.h"
#include "Console.h"
#include <ctime>
#include "DList.h"

#define size_type int


int _tmain()
{
	System::Console::SetBufferSize(80, 40);
	System::Console::SetWindowSize(80, 40);
	
	System::Console::CursorVisible(false);
	System::Console::EOLWrap(false);

	srand(static_cast<unsigned int> (time(NULL)));

	typedef DList<char> OurDList;
	OurDList testDList;
	testDList.Push_Front('#');
	testDList.Push_Back('@');
	testDList.Clear();
	testDList.Push_Back('i');
	testDList.Push_Front('r');
	testDList.Push_Front('h');
	testDList.Push_Back('s');
	testDList.Push_Front('t');
	testDList.Erase(2);
	testDList.Erase(0);
	testDList.Erase(2);
	for (size_type i = 0; i < testDList.Size(); i++)
		cout << testDList[i];

	testDList.Erase(0);
	testDList.Erase(0);
	testDList.Push_Front('!');
	testDList.Push_Back('\"');
	testDList.Erase(1);
	for (size_type i = 0; i < testDList.Size(); i++)
		cout << testDList[i];
	cout << "\n";

	cout << flush << endl;
	cout << strlen("*");
	system("pause");

	


#if 1

	Game g;
	g.Play();

#endif // 0





	System::Console::SetCursorPosition((System::Console::WindowWidth() - 31) / 2, System::Console::WindowHeight() - 1);
	System::Console::CursorVisible(true);
	//system("pause");

	
	return 0;
}

