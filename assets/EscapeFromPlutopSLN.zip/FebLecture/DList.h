#pragma once
#include<cstdio>


#define size_type int
template<class cyan = int>
class DList
{
	

	struct node
	{
		cyan data;
		node* n, *p;
		// next is se to null becay
		node(const cyan& _data, node * _p, node * _n) : data(_data), p(_p), n(_n) {};
		//node(const cyan& _data, node * _p// next !!!! pointer) : data(_data), p(_p), n(NULL) {};

	};

	size_type size;
	node *first, *last;


public:

	DList() { size = 0; first = last = NULL; };
	~DList();

	size_type Size() { return size; }
	void Push_Back(const cyan& _data);
	void Push_Front(const cyan& data);
	bool Erase(int _index);
	void Clear();
	
	
	cyan& operator[](int index);
	const cyan& operator[](int index) const;
	//cyan& operator<<(ostream & _os, DList& _cyan);
	//const DList& operator<<(ostream & _os,DList& _cyan);
};

template<typename cyan>
void DList<cyan>::Push_Back(const cyan& _data)
{                                 //| this is setting up the previous pointer
	node* temp = new node(_data , last, NULL);
	//          L
	//   l <- temp - > X

	
	if (first == NULL)
	{
		first = temp;
	}
	else
	{
		last->n = temp;
	}
	last = temp;
	++size;

}

template<class cyan>
inline void DList<cyan>::Push_Front(const cyan & data)
{
	node * temp = new node(data,NULL, first);

	if (last == NULL)
		last = temp;
	else
		first->p = temp;
	first = temp;

	size++;

}

template<typename cyan>
void DList<cyan>::Clear() // clears the list 
{

	node *pDel = first;
	
	/* Traverse the list and delete the node one by one from the head */
	while (first) 
	{
		pDel = first;

		first = first->n;
		delete pDel;
	}
	last = first = NULL;
	size = 0;

}

template<class cyan>
inline bool DList<cyan>::Erase(int index)
{
	
	node * temp;

	if (index >= 0 && index < size)
	{
		if (size == 1)
		{
			Clear();
			return true;
		}

		else if (index == 0)
		{
			temp = first;
			first->n->p = NULL;
			first = first->n;
			delete temp;
			size--;
			return true;
		}
		else if (index == size -1)
		{
			temp = last;
			last->p->n = NULL;
			last = last->p;
			delete temp;
			size--;
			return true;
		}
		else 
		{
			temp = first;
			for (int i = 0; i < index; i++)
			{
				temp = temp->n;
			}
			temp->p->n = temp->n;
			temp->n->p = temp->p;
			delete temp;
				size--;
			return true;
		}

	}

	return false;
}

template<typename cyan>
DList<cyan>::~DList()
{
	node* temp = first;

	while (first)
	{
		temp = first;
		first = first->n;
		delete temp;
	}
}

template<typename cyan>
cyan& DList<cyan>::operator[](int index)
{
	node * temp = first;
	if (index < 0 || index > size)
	{
		index = 0;
	}

	for (int i = 0; i< index; ++i)
	{
		temp = temp->n;
	}

	return temp->data;
}

template<typename cyan>
const cyan& DList<cyan>::operator[](int index) const
{
	node * temp = first;
	if (index < 0 || index > size)
	{
		index = 0;
	}

	for (int i = 0; i< index; ++i)
	{
		temp = temp->next;
	}

	return temp->data;
}







