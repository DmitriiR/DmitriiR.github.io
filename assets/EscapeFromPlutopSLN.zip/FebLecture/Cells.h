#pragma once
#include "BaseObject.h"

struct Cell 
{

	int oX, oY;
	System::ConsoleColor fg, bg;
	char sym;

	Cell() { }
	Cell(int _x, int _y, ConsoleColor _fg, ConsoleColor _bg, char _sym);

	bool Show(int _left, _int top) const;

public:
	Cell();
~Cell();
};

