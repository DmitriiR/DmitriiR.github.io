#include "stdafx.h"
#include "GameState.h"
#include "BaseObject.h"
#include "MenuState.h"
#include "Game.h"
#include "Enemy.h"
#include "Player.h"
#include "Valkyrie.h"
#include "Falcon.h"
#include "Nemo.h"
#include "Missile.h"
#include "MissileBomb.h"
#include "Cell.h"
#include <vector>
#include <algorithm>
#include <ctime>
#include "EnemyBoss.h"
#include "EnemyUnderBoss.h"

vector<BaseObject*> GameState::objects;
char GameState::cheats = 0;

//BaseObject** GameState::objects;
//int numObjects = 3;

//Cell** CellArray = new Cell*[rand() % 11 + 10];

GameState::GameState()
{
	objects.resize(6);
	//walls =
	//GameLevel = new Level;

	//Initializing an array of POINTERS to BaseObjects, slot 0 being an example of upcasting
	//objects = new BaseObject*[numObjects];

	objects[0] = new Player(0, 13, " / \\\n |^| \n<[|]>", System::ConsoleColor::White, System::ConsoleColor::Blue, 1, 1, "Rad McBad");
	objects[1] = new Enemy();
	objects[2] = new Enemy(0, 7, "|", System::ConsoleColor::Cyan, System::ConsoleColor::Magenta);
	objects[3] = new Enemy(20, 7, "D=", System::ConsoleColor::Cyan, System::ConsoleColor::Magenta);
	objects[4] = new Enemy(20, 7, "D=", System::ConsoleColor::Cyan, System::ConsoleColor::Magenta);
	objects[5] = new Enemy(20, 7, "D=", System::ConsoleColor::Cyan, System::ConsoleColor::Magenta);

	objects.push_back(new Missile());

	time(&rawtime);
	
	for (int i = 0; i < numStarsShow; i++)
	{
		star[i][XStar] = rand() % System::Console::WindowWidth();
		star[i][YStar] = rand() % System::Console::WindowHeight() - 2;
	}


}


GameState::~GameState()
{
	
	
	//Delete not only the array, but the dynamic objects inside the array
	decltype(objects.size()) i = 0;
	for (; i < objects.size(); ++i)
	{
		delete objects[i];
	}
}

bool GameState::Input()
{
	if (GetAsyncKeyState(VK_F1))
	{

		cheats ^= ENEMY_MOVE;
		System::Console::FlushKeys();
		Sleep(1000);
		
	}
	if (GetAsyncKeyState(VK_F2))
	{

		cheats ^= POINTS_FLAG;
		System::Console::FlushKeys();

		Sleep(1000);

	}
	if (GetAsyncKeyState(VK_F3))
	{

		cheats ^= ENEMY_SHOOT;
		System::Console::FlushKeys();

		Sleep(1000);

	}

	
	//Call input for any objects
	decltype(objects.size()) i = 0;
	for (; i < objects.size(); ++i)
	{
		//Accounts for if the player hit escape and quits
		if (!objects[i]->Input())
		{
			return false;
		}
	}

	return true;
}

void GameState::Update(int _frame)
{
	frame = _frame;
	//Update any objects
	
	
	
	decltype(objects.size()) i = 0;
	for (; i < objects.size(); ++i)
	{
		objects[i]->Update(_frame);
	}
	
	
	if (objects[0]->GetAlive())
	{
		auto iter = objects.begin();
		for (int j = 0; j < (int)objects.size(); ++j)
		{
			if (!objects[j]->GetAlive())
			{
				iter = objects.begin() + j;
				delete objects[j];
				objects.erase(iter);
			}

			if (objects.size() <= 1)
			{
				
				Levels(level);
			
				level++;
			}
			
			
		}
		
		frameDrag++;

			if (frameDrag > 2)
			frameDrag = 0;
		for (int k = 0; k < numStarsShow; k++)
		if (objects[0]->GetAlive()  && frameDrag == 2)
		{
			{
				if (System::Console::WindowHeight() - 2 <= ++star[k][YStar])
				{
					star[k][YStar] = 0;
					star[k][XStar] = rand() % System::Console::WindowWidth();
				}
			}
		}



	} else
	Game::ChangeState(MENU_STATE);
	

	//System::Console::Lock(true);

	//System::Console::Lock(false);
}

void GameState::Render() const
{	
	// shows the time
	System::Console::SetCursorPosition(61, 42);
	int fps = frame / (int)(time(0) - rawtime);
	int playTime = (int)(time(0) - rawtime);
	cout << "Time: " << playTime <<"s";
	System::Console::SetCursorPosition(73, 42);
	cout << fps << " fps";
	
	System::Console::ForegroundColor(8);

	if (objects[0]->GetAlive())
	{
		for (int k = 0; k < numStarsShow; k++)
		{
			System::Console::SetCursorPosition(star[k][XStar], star[k][YStar]);
			cout << (char)250;
		}
	}
	
	
	//Render any objects
	decltype(objects.size()) i = 0;
	for (; i < objects.size(); ++i)
	{
		if (objects[i]->GetAlive())
		{
			objects[i]->SetLifeTime(playTime);
			objects[i]->Render();
		}
	}
	

	/*for (int i = 0; i < 10; i++)
	{
		CellArray[i]->SetX(rand() % 10);
		CellArray[i]->SetY(rand() % 10);
		System::Console::SetCursorPosition(CellArray[i]->GetX(), CellArray[i]->GetY());
		cout << CellArray[i]->GetSym();
	}*/
}

void GameState::Enter()
{
	ifstream fin;
	System::Console::SetCursorPosition(0, 17);

	int counter = 0;
	int numRecords = 0;
	int recordIndex = 0;
	int chosenShip = 0;
	int Index = 0;
	
	

	
	
	//objects[3] = new BaseObject(0, 10, "D=", System::ConsoleColor::Cyan, System::ConsoleColor::Magenta);

	
	fin.open("settings.txt");
	//char buffer[32];
	char name[30];
	bool empty = 1; // if the default player is seleced 
	if (fin.is_open()) {

		fin >> chosenShip;
		fin.ignore(LLONG_MAX, '\n');
		fin.get(name, 30, '\n');
		fin >> empty;
		fin.close();
		//system("pause");
		//cout << name;
	}

	fin.open("ships1.txt");

	if (fin.is_open()) {

		// reads the number of records

		//fin >> numRecords;

		Player* tempObject = new Player[3];

		fin >> Index;
		fin.ignore(LLONG_MAX, '\n');
		fin >> numRecords;
		//fin.ignore(LLONG_MAX, '\n');
	//	cout << "Chosen ship :" << Index << " records: " << numRecords << "\n";

		while (!fin.eof())
		{

			char output[30];
			
			int  Xpos, Ypos, fg, bg;
			fin.ignore(LLONG_MAX, '\n');// ignores the new line 

			fin.get(output, 30, '\t');
			fin >> Xpos;
			fin >> Ypos;
			fin >> fg;
			fin >> bg;
			
			if (empty == 1 )
			{
				strcpy_s(name,20,System::Console::RandomName());
			}
			else
			{
				//fin.get(name, 30, '\n');
			}
			
			if (recordIndex == chosenShip)
			{
				
				switch (chosenShip)
				{
				
				
				case 0: objects[0] = new Valkyrie(Xpos, Ypos, output, System::ConsoleColor(fg), System::ConsoleColor(bg), 1, 1, name); break;
				case 1: objects[0] = new Falcon(Xpos, Ypos, output, System::ConsoleColor(fg), System::ConsoleColor(bg), 1, 1, name); break;
				case 2: objects[0] = new Nemo(Xpos, Ypos, output, System::ConsoleColor(fg), System::ConsoleColor(bg), 1, 1, name); break;
				default:
				objects[0] = new Player(Xpos, Ypos, output, System::ConsoleColor(fg), System::ConsoleColor(bg), 1, 1, name);
				break;
				}

				//objects[1] = new Enemy(Xpos+5, Ypos+5, output, System::ConsoleColor(fg), System::ConsoleColor(bg));
				objects[1] = new Enemy();
				objects[1]->SetX(10);
				objects[1]->SetY(5);
				objects[2] = new Enemy();
				objects[2]->SetX(35);
				objects[2]->SetY(5);
				objects[3] = new Enemy();
				objects[3]->SetX(70);
				objects[3]->SetY(5);
				objects[4] = new Enemy();
				objects[4]->SetX(63);
				objects[4]->SetY(10);
				objects[5] = new Enemy();
				objects[5]->SetX(15);
				objects[5]->SetY(10);
			
				//time(&rawtime);
				objects[0]->SetLifeTime(0);

				//objects[0]->SetX(35);
				//objects[0]->SetY(20);

				break;
			}
			else
			{
				recordIndex++;
				//objects[1] = new Enemy();
			}
		}
		fin.close();
	}




	//for (int i = 0; i < 20; i++)
	//{
		//System::Console::Lock(true);
		//System::Console::DrawBox(39-i*2, 20 - i, 1 + i*4, 1+i*2-2, false);
		System::Console::Clear();
		System::Console::SetCursorPosition(30, 22);
		System::Console::ForegroundColor(8);
		cout << "Use ";
		System::Console::ForegroundColor(14);
		cout << "[SPACE]";
		System::Console::ForegroundColor(8);
		cout << " to fire";
		System::Console::SetCursorPosition(28, 23);

		cout << "Use ";
		System::Console::ForegroundColor(14);
		cout << "[ARROW KEYS]";
		System::Console::ForegroundColor(8);
		cout<<" to move";
		System::Console::ForegroundColor(8);
		System::Console::SetCursorPosition(30,20);
		for (int j = 0; j < 20; j++)
		{
			cout << (char)176;
		}
		System::Console::SetCursorPosition(30, 20);
		System::Console::ForegroundColor(15);

		for (size_t j = 0; j < 20; j++)
		{
			cout << (char)219;
			Sleep(50);
		}
	//	System::Console::Lock(false);
	//	Sleep(40);
	//	System::Console::Clear();
	//}


	System::Console::FlushKeys();

}

void GameState::Exit()
{

	System::Console::Clear();
	
	
	Player* p = dynamic_cast<Player*>(objects[0]);
	
	PlayerInfo info;
	vector<PlayerInfo> scores;
	fstream bout;
	fstream bing;

	
	
	
	int lineCounter = 0;
	level = 1;
	
	MenuState* mp = dynamic_cast<MenuState*>(objects[0]);
	mp->MenuFrame();

	

	


	bing.open("scores.bin", ios_base::binary | ios_base::in);
	if (bing.is_open())
	{
		bing.seekg(0, ios_base::end);
		int size = (int)bing.tellg();
		size /= sizeof(PlayerInfo);
		bing.seekg(0, ios_base::beg);
		scores.resize(size);
		if (size != 0) bing.read((char*)&scores[0], sizeof(PlayerInfo) * size);
		bing.close();
	}

	strcpy_s(info.name, 32, p->GetName());
	info.score = p->GetScore();
	strcpy_s(info.ship, 10, p->GetShip());
	info.diff = p->GetDiff();
	scores.push_back(info);


	// write to file 
	bout.open("scores.bin", ios_base::binary | ios_base::out | ios_base::trunc);
	if (bout.is_open())
	{
		bout.write((char*)&scores[0], sizeof(PlayerInfo)* scores.size());
		bout.close();
	}

	for (int i = 0; i < (int)scores.size() - 1; ++i)
	{

		for (int j = i + 1; j < (int)scores.size(); j++)
		{
			if (scores[j].score > scores[i].score)
			{

				swap(scores[j], scores[i]);
			}
		}
	}

	System::Console::SetCursorPosition(37, 33);
	System::Console::ForegroundColor(15);
	cout << "GAME OVER";
	System::Console::DrawBox(8,lineCounter + 8,63,22,true);
	System::Console::ForegroundColor(7);													   // print out content:
	

	System::Console::SetCursorPosition(14, lineCounter+7);
	cout << "----------======= TOP 20 SCORES ============-----\n";
	System::Console::SetCursorPosition(11, lineCounter + 8);
	cout << "Name                     Ship          Score      Time";
	for (vector<PlayerInfo>::iterator it = scores.begin(); (it != scores.end()) && (lineCounter < 20); ++it)
		{
			if (it->score == p->GetScore() && (strcmp(it->name,p->GetName()) == 0))
			{
				System::Console::ForegroundColor(14);
			}
			else
			System::Console::ForegroundColor(8);
			
			System::Console::SetCursorPosition(9,lineCounter  + 9);
			
			if (lineCounter < 9)
			{
				cout << lineCounter + 1 << ".   ";
			}
			else cout << lineCounter + 1 << ".  ";
			cout << *it;
			lineCounter++;

		}
		
		std::cout << '\n';

		System::Console::ForegroundColor(15);		   // print out content:

	


	System::Console::SetCursorPosition(25, 35);
	System::Console::FlushKeys();
	Sleep(1000);
	system("pause");
}

void GameState::LoadShip()
{


	ifstream fin;
	int counter = 0;
	System::Console::SetCursorPosition(0, 17);
	fin.open("ships.txt");

	int chosenShip = 0;
	int recordIndex = 0;
	if (fin.is_open()) {

		// reads the number of records

		fin >> chosenShip;
		cout << "Reading from file with : " << chosenShip << " records\n";

		Player* tempObject = new Player[chosenShip];
		


		while (!fin.eof())
		{

			char output[100];
			int  Xpos, Ypos, fg, bg;
			fin.ignore(LLONG_MAX, '\n');
			fin.get(output, 100, '\t');
			fin >> Xpos;
			fin >> Ypos;
			fin >> fg;
			fin >> bg;

			// casting to system color
	/*		tempObject[recordIndex].SetPicture(output);
			tempObject[recordIndex].SetX(Xpos + 1);
			tempObject[recordIndex].SetY(Ypos + 18);

			tempObject[recordIndex].SetFG((System::ConsoleColor)(System::ConsoleColor)(fg));
			tempObject[recordIndex].SetBG((System::ConsoleColor)(System::ConsoleColor)(bg));

			tempObject[recordIndex].Render();*/

			objects[0] = new Player(Xpos, Ypos, output, System::ConsoleColor(fg), System::ConsoleColor(bg), 1, 1, "Rad McBad");


			/*cout << tempObject[recordIndex].GetText();
			cout << endl;
			cout << "Temp Object[" << recordIndex << "] X:" << tempObject[recordIndex].GetX() << '\n';
			cout << "Temp Object[" << recordIndex << "] Y:" << tempObject[recordIndex].GetY() << '\n';
			cout << "Temp Object[" << recordIndex << "] FG:" << tempObject[recordIndex].GetFG() << '\n';
			cout << "Temp Object[" << recordIndex << "] BG:" << tempObject[recordIndex].GetBG() << '\n';
			*/
			cout << '\n';

			if (recordIndex == chosenShip - 1)
			{
				break;
			}
			else
				recordIndex++;
		}
	}

}

void GameState::Levels(int _Level)
{
	switch (_Level)
	{
	case 1:
		objects.resize(4);
		System::Console::SetCursorPosition(35, 20);
		cout << "Level " << _Level + 1;
		Sleep(2000);
		objects[1] = new Enemy(5, 2, "/:\\\n\\|/", System::ConsoleColor::Yellow, System::ConsoleColor::Black);
		//objects[1]->SetLife(100*level);
		objects[1]->SetID(ENEMY);
		objects[1]->SetLife(200 * _Level);
		objects[1]->SetAlive(true);

		objects[2] = new Enemy(10, 5, "/:\\\n\\|/", System::ConsoleColor::Yellow, System::ConsoleColor::Black);
		//objects[1]->SetLife(100*level);
		objects[2]->SetID(ENEMY);
		objects[2]->SetLife(200 * _Level);
		objects[2]->SetAlive(true);

		objects[3] = new Enemy(50, 5, "/:\\\n\\|/", System::ConsoleColor::Yellow, System::ConsoleColor::Black);
		//objects[1]->SetLife(100*level);
		objects[3]->SetID(ENEMY);
		objects[3]->SetLife(200 * _Level);
		objects[3]->SetAlive(true);
		break;
	case 2:

		objects.resize(5);
		System::Console::SetCursorPosition(35, 20);
		cout << "Level " << _Level + 1;
		Sleep(1500);
		objects[1] = new EnemyUnderBoss(10, 2, " [^^] \n \\||/", System::ConsoleColor::Gray, System::ConsoleColor::Black);
	
		objects[1]->SetID(ENEMY);
		objects[1]->SetLife(200 * _Level);
		objects[1]->SetAlive(true);

		objects[2] = new EnemyUnderBoss(50, 2, " [^^] \n \\||/", System::ConsoleColor::Gray, System::ConsoleColor::Black);
		
		objects[2]->SetID(ENEMY);
		objects[2]->SetLife(200 * _Level);
		objects[2]->SetAlive(true);

		objects[3] = new Enemy(5, 10, "/:\\\n\\|/", System::ConsoleColor::Yellow, System::ConsoleColor::Black);
		//objects[1]->SetLife(100*level);
		objects[3]->SetID(ENEMY);
		objects[3]->SetLife(200 * _Level);
		objects[3]->SetAlive(true);
		
		objects[4] = new Enemy(50, 20, "/:\\\n\\|/", System::ConsoleColor::Yellow, System::ConsoleColor::Black);
		//objects[1]->SetLife(100*level);
		objects[4]->SetID(ENEMY);
		objects[4]->SetLife(200 * _Level);
		objects[4]->SetAlive(true);

		
		break;
	default:

		objects.resize(4);
		System::Console::SetCursorPosition(37, 20);
		cout << "BOSS !";
		Sleep(1500);
		objects[1] = new EnemyBoss(40, 2, "/[]_[]\\\n<| _ |>\n \\| |/", System::ConsoleColor::Cyan, System::ConsoleColor::Black);

		objects[1]->SetID(ENEMY);
		objects[1]->SetLife(1000 * _Level);
		objects[1]->SetAlive(true);
	
		objects[2] = new Enemy(10, 5, "/:\\\n\\|/", System::ConsoleColor::Yellow, System::ConsoleColor::Black);
		//objects[1]->SetLife(100*level);
		objects[2]->SetID(ENEMY);
		objects[2]->SetLife(200 );
		objects[2]->SetAlive(true);
		
		objects[3] = new Enemy(60, 5, "/:\\\n\\|/", System::ConsoleColor::Yellow, System::ConsoleColor::Black);
		//objects[1]->SetLife(100*level);
		objects[3]->SetID(ENEMY);
		objects[3]->SetLife(200 );
		objects[3]->SetAlive(true);

		break;
	}

	
}