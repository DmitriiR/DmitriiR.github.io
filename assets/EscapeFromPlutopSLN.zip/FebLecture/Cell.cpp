#include "stdafx.h"
//#include "Cell.h"

//
//Cell::Cell()
//{
//	SetX(10);
//	SetY(10);
//	SetFG(System::ConsoleColor::Red);
//	SetBG(System::ConsoleColor::Yellow);
//	SetSym('0');
//}
//
//
//Cell::~Cell()
//{
//
//}
//
//Cell::Cell(int _x, int _y, System::ConsoleColor _fg, System::ConsoleColor _bg, char _sym)
//{
//	SetX(_x);
//	SetY(_y);
//	SetFG(_fg);
//	SetBG(_bg);
//	SetSym(_sym);
//}
//
//bool Cell::Show(int _left, int _top) const
//{
//	//System::Console::ForegroundColor(GetFG());
//	//System::Console::BackgroundColor(GetBG());
//	
//	if (!(_left < 0 || _left > System::Console::WindowWidth() || _top < 0 || _top > System::Console::WindowHeight()))
//	{
//		System::Console::SetCursorPosition(_left,_top);
//		cout << GetSym();
//		return true;
//	}
//	else return false;
//	
//	
//}





