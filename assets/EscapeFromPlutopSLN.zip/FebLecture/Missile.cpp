#include "stdafx.h"
#include "Missile.h"
#include "GameState.h"
#include "Player.h"
#include "Enemy.h"

#define EXPLOSIONSPEED 10

Missile::Missile() : BaseObject(-1,-1, (char)179,System::ConsoleColor::Cyan, System::ConsoleColor::Black)
{
	velVec.resize(2);
	char buff[2];
	sprintf_s(buff, "%c", (char)179);
	SetPicture(buff); // destination, format string - %c character designation %i integer %s string, rest of the parameters can be listed  
	//SetPicture("*");
	//CalcWH();
	//SetFG(System::ConsoleColor::Cyan);
	//SetBG(System::ConsoleColor::DarkYellow);
	//SetX(-1);
	//SetY(-1);

	SetAlive(false);

	//SetID(MISSILE);
}


Missile::~Missile()
{
}

bool Missile::Input()
{
	return true;
}

void Missile::Update(int _frame)
{
	if (GetAlive() && (_frame % 3))
	{
	bool colliding = false;
		//Check collisions
		vector<BaseObject*> tempObjects = GameState::GetObjects();

		decltype(tempObjects.size()) i = 0;
		for (; i < tempObjects.size(); ++i)
		{
			
			
				if (tempObjects[i]->GetID() == ENEMY)
				{
				//Checking current XPos instead of updated XPos
				BaseObject* target = tempObjects[i];
				if (GetX() + GetWidth() <= target->GetX() ||
					GetX() > target->GetX() + target->GetWidth() ||
					GetY() > target->GetY() + target->GetHeight() ||
					GetY() + GetHeight() < target->GetY())
				{
					colliding = false;
					continue;
				}
				else
				{
					if (GetID() != ENEMY_MISSILE)
					{
						System::Console::SetCursorPosition(GetX(), GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "*";
						System::Console::SetCursorPosition(GetX() - 1, GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "{ }";
						System::Console::SetCursorPosition(GetX() - 2, GetY());
						Sleep(EXPLOSIONSPEED);
						cout << "(   )";

						target->SetLife(target->GetLife() - GetDamage());

						colliding = false;
						SetAlive(false);
						Player* p = dynamic_cast<Player*>(tempObjects[0]);
						p->SetScore(p->GetScore() + GetLifeTime() + GetDamage());
					}
					break;
				}
			}
		

			if (tempObjects[i]->GetID() == PLAYER)
			{
				//Checking current XPos instead of updated XPos
				BaseObject* target = tempObjects[i];
				if (GetX() + GetWidth() < target->GetX() ||
					GetX() > target->GetX() + target->GetWidth() ||
					GetY() > target->GetY() + target->GetHeight() ||
					GetY() + GetHeight() < target->GetY()) 
					
				{
					
					colliding = false;
					
					continue;
				}
				else 
				{
					
					if (GetID() != PLAYER_MISSILE)
					{
					System::Console::ForegroundColor(12);
					System::Console::DrawBox(0,0, System::Console::WindowWidth(), System::Console::WindowHeight()-1,false);
					
					System::Console::ForegroundColor(15);
					System::Console::SetCursorPosition(GetX(), GetY());
					Sleep(EXPLOSIONSPEED);
					cout << "*";
					System::Console::ForegroundColor(15);
					System::Console::SetCursorPosition(GetX() - 1, GetY());
					Sleep(EXPLOSIONSPEED);
					cout << "{ }";
					System::Console::ForegroundColor(8);
					System::Console::SetCursorPosition(GetX() - 2, GetY());
					Sleep(EXPLOSIONSPEED);
					cout << "(   )";
					/*System::Console::ForegroundColor();
					System::Console::SetCursorPosition(0, 0);
					for (int i = 0; i < System::Console::WindowWidth(); i++)
					{
						cout << (char)223;
					}*/
					

					target->SetLife(target->GetLife() - GetDamage());
					Player* p = dynamic_cast<Player*>(tempObjects[0]);
					p->SetScore(p->GetScore() - this->GetDamage() * 5);
					colliding = false;
					SetAlive(false);
					
					}
					//Player* p = dynamic_cast<Player*>(tempObjects[0]);
					//p->SetScore(p->GetScore() + 1);
					
					break;
				}

			}

		}


		int newX = GetX() + velX;
		int newY = GetY() + velY;
		if (newX + GetWidth() <= System::Console::WindowWidth() &&
			newX >= 0
			&&
			newY + GetHeight() <= System::Console::WindowHeight() - 2 &&
			newY >= 1)
		{
			colliding = false;
		}
		else
		{
			colliding = true;
			SetAlive(false);
		}

		if (!colliding)
		{
		SetX(newX);
		SetY(newY);
		}

	}
}

void Missile::Render() const
{
	if (GetAlive())
		BaseObject::Render();

}

void Missile::Explosion()
{
}

